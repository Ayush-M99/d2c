// d2c — Map Overlays: Zone polygons, floating analytics cards, heatmap, time slider, popovers

// ── Zone Definitions with polygon coordinates ─────────────────────────
const MAP_ZONES = [
  { id:'food', label:'Gourmet Trail', color:'#FF6B35', center:[12.9725,77.6055],
    polygon:[[12.9745,77.6020],[12.9755,77.6070],[12.9735,77.6090],[12.9710,77.6075],[12.9705,77.6030]],
    stats:{ threads:3, active:36, peak:'8pm', topTags:['cafe','ramen','street-food'],
      hourly:[2,1,1,0,0,1,3,5,8,12,15,18,22,28,32,36,34,30,38,42,35,22,14,6] }},
  { id:'nightlife', label:'Nightlife Strip', color:'#FF3CAC', center:[12.9755,77.6195],
    polygon:[[12.9775,77.6165],[12.9780,77.6220],[12.9755,77.6235],[12.9735,77.6215],[12.9740,77.6170]],
    stats:{ threads:2, active:51, peak:'11pm', topTags:['pub','live-music','drinks'],
      hourly:[1,0,0,0,0,0,0,1,2,3,5,8,10,12,15,20,24,30,38,45,51,48,32,12] }},
  { id:'culture', label:'Arts Hub', color:'#8B5CF6', center:[12.9690,77.5985],
    polygon:[[12.9715,77.5955],[12.9720,77.6010],[12.9700,77.6025],[12.9670,77.6005],[12.9665,77.5960]],
    stats:{ threads:2, active:24, peak:'6pm', topTags:['open-mic','pottery','gallery'],
      hourly:[0,0,0,0,0,0,1,2,4,8,12,16,18,20,22,24,22,20,18,14,10,6,3,1] }},
  { id:'outdoors', label:'Cubbon Green', color:'#06D6A0', center:[12.9763,77.5929],
    polygon:[[12.9785,77.5900],[12.9790,77.5955],[12.9770,77.5970],[12.9745,77.5955],[12.9740,77.5905]],
    stats:{ threads:1, active:8, peak:'7am', topTags:['walk','run','monsoon'],
      hourly:[2,1,0,0,0,4,8,12,10,8,6,4,3,3,4,5,6,8,7,5,3,2,2,2] }},
  { id:'transit', label:'Transit Core', color:'#4CC9F0', center:[12.9784,77.6408],
    polygon:[[12.9805,77.6380],[12.9810,77.6435],[12.9790,77.6445],[12.9765,77.6430],[12.9760,77.6385]],
    stats:{ threads:1, active:22, peak:'9am', topTags:['power-cut','traffic','metro'],
      hourly:[3,2,1,1,0,2,8,18,22,20,16,14,12,10,12,15,18,20,22,18,12,8,5,3] }},
];

// ── Activity data by hour (aggregate) ─────────────────────────────────
function getHourlyAggregate() {
  const agg = new Array(24).fill(0);
  MAP_ZONES.forEach(z => z.stats.hourly.forEach((v, i) => agg[i] += v));
  return agg;
}

// ── Mini Sparkline SVG ────────────────────────────────────────────────
function Sparkline({ data, color, width=100, height=28, filled=true }) {
  const max = Math.max(...data, 1);
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * width},${height - (v / max) * (height - 4)}`);
  const line = pts.join(' ');
  const fillPts = `0,${height} ${line} ${width},${height}`;
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={{display:'block'}}>
      {filled && <polygon points={fillPts} fill={`${color}20`} />}
      <polyline points={line} fill="none" stroke={color} strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" />
      {/* Current hour dot */}
      {(() => {
        const h = new Date().getHours();
        const x = (h / 23) * width;
        const y = height - (data[h] / max) * (height - 4);
        return <circle cx={x} cy={y} r={3} fill={color} stroke="#fff" strokeWidth={1} />;
      })()}
    </svg>
  );
}

// ── Mini Bar Chart ────────────────────────────────────────────────────
function MiniBarChart({ labels, values, colors, width=120, height=40 }) {
  const max = Math.max(...values, 1);
  const bw = (width - (values.length - 1) * 3) / values.length;
  return (
    <svg width={width} height={height + 14} viewBox={`0 0 ${width} ${height + 14}`}>
      {values.map((v, i) => {
        const bh = (v / max) * height;
        const x = i * (bw + 3);
        return (
          <g key={i}>
            <rect x={x} y={height - bh} width={bw} height={bh} rx={2}
              fill={colors[i] || '#8B5CF6'} opacity={0.85} />
            <text x={x + bw/2} y={height + 11} textAnchor="middle"
              fontSize={7} fill="rgba(255,255,255,0.5)" fontFamily="'JetBrains Mono',monospace">
              {labels[i]}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

// ── Heatmap Grid ──────────────────────────────────────────────────────
function HeatmapGrid({ data, width=100, height=50 }) {
  // data is 2D array [rows][cols] of 0-1 values
  const rows = data.length, cols = data[0].length;
  const cw = width / cols, ch = height / rows;
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
      {data.map((row, r) => row.map((v, c) => (
        <rect key={`${r}-${c}`} x={c * cw} y={r * ch} width={cw - 0.5} height={ch - 0.5} rx={1}
          fill={v > 0.7 ? '#EF4444' : v > 0.4 ? '#FF6B35' : v > 0.2 ? '#FFD166' : '#06D6A022'}
          opacity={0.3 + v * 0.7} />
      )))}
    </svg>
  );
}

// ── Floating Analytics Card (Leaflet Custom Overlay) ──────────────────
function AnalyticsCard({ zone, darkMode, onClick, style: extraStyle }) {
  const [hov, setHov] = React.useState(false);
  const bg = darkMode ? 'rgba(10,10,20,0.92)' : 'rgba(255,255,255,0.95)';
  const border = darkMode ? `${zone.color}44` : `${zone.color}33`;
  const text = darkMode ? '#F0F0F8' : '#111';
  const text2 = darkMode ? '#A0A0BE' : '#666';

  return (
    <div onClick={onClick}
      onPointerEnter={() => setHov(true)} onPointerLeave={() => setHov(false)}
      style={{
        background: bg, backdropFilter: 'blur(16px)',
        border: `1px solid ${hov ? zone.color + '88' : border}`,
        borderRadius: 12, padding: '10px 12px',
        minWidth: 140, maxWidth: 170,
        cursor: 'pointer', userSelect: 'none',
        boxShadow: hov
          ? `0 8px 32px rgba(0,0,0,0.5), 0 0 20px ${zone.color}22`
          : '0 4px 20px rgba(0,0,0,0.4)',
        transform: hov ? 'scale(1.03)' : 'scale(1)',
        transition: 'all 0.2s',
        ...extraStyle,
      }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
        <div style={{ width: 8, height: 8, borderRadius: '50%', background: zone.color,
          boxShadow: `0 0 8px ${zone.color}` }} />
        <span style={{ fontSize: 11, fontWeight: 700, color: zone.color,
          fontFamily: "'Space Grotesk',sans-serif", letterSpacing: '-0.01em' }}>
          {zone.label}
        </span>
      </div>
      {/* Stats row */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 8 }}>
        <div>
          <div style={{ fontSize: 20, fontWeight: 700, color: text, lineHeight: 1,
            fontFamily: "'Space Grotesk',sans-serif" }}>{zone.stats.active}</div>
          <div style={{ fontSize: 8, color: text2, fontFamily: "'JetBrains Mono',monospace",
            marginTop: 2, letterSpacing: '0.06em' }}>ACTIVE</div>
        </div>
        <div>
          <div style={{ fontSize: 20, fontWeight: 700, color: text, lineHeight: 1,
            fontFamily: "'Space Grotesk',sans-serif" }}>{zone.stats.threads}</div>
          <div style={{ fontSize: 8, color: text2, fontFamily: "'JetBrains Mono',monospace",
            marginTop: 2, letterSpacing: '0.06em' }}>THREADS</div>
        </div>
        <div>
          <div style={{ fontSize: 12, fontWeight: 600, color: zone.color, lineHeight: 1,
            fontFamily: "'JetBrains Mono',monospace", marginTop: 4 }}>{zone.stats.peak}</div>
          <div style={{ fontSize: 8, color: text2, fontFamily: "'JetBrains Mono',monospace",
            marginTop: 2, letterSpacing: '0.06em' }}>PEAK</div>
        </div>
      </div>
      {/* Sparkline */}
      <Sparkline data={zone.stats.hourly} color={zone.color} width={140} height={24} />
      {/* Tags */}
      <div style={{ display: 'flex', gap: 3, marginTop: 6, flexWrap: 'wrap' }}>
        {zone.stats.topTags.slice(0, 3).map(t => (
          <span key={t} style={{ fontSize: 8, padding: '1px 5px', borderRadius: 10,
            background: `${zone.color}18`, color: zone.color, fontWeight: 600,
            fontFamily: "'JetBrains Mono',monospace", border: `1px solid ${zone.color}33` }}>
            #{t}
          </span>
        ))}
      </div>
    </div>
  );
}

// ── Zone Detail Popover ───────────────────────────────────────────────
function ZonePopover({ zone, onClose, darkMode }) {
  const bg = darkMode ? 'rgba(10,10,20,0.96)' : 'rgba(255,255,255,0.98)';
  const text = darkMode ? '#F0F0F8' : '#111';
  const text2 = darkMode ? '#A0A0BE' : '#555';
  const text3 = darkMode ? '#606080' : '#999';
  const surfBg = darkMode ? 'rgba(20,20,35,0.8)' : '#F5F5F8';

  // Generate heatmap data (7 days x 24 hours, simulated)
  const heatData = Array.from({ length: 7 }, (_, day) =>
    zone.stats.hourly.map(v => {
      const noise = 0.5 + Math.random() * 0.5;
      const dayFactor = day < 5 ? 0.8 : 1.2;
      return Math.min(1, (v / Math.max(...zone.stats.hourly)) * dayFactor * noise);
    })
  );

  // Category breakdown
  const categories = [
    { label: 'Chat', value: Math.round(zone.stats.active * 0.45), color: zone.color },
    { label: 'Poll', value: Math.round(zone.stats.active * 0.25), color: '#FFD166' },
    { label: 'Q&A', value: Math.round(zone.stats.active * 0.20), color: '#4CC9F0' },
    { label: 'Event', value: Math.round(zone.stats.active * 0.10), color: '#06D6A0' },
  ];

  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 2000,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)',
    }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{
        background: bg, backdropFilter: 'blur(24px)',
        border: `1px solid ${zone.color}44`,
        borderRadius: 20, padding: 20, width: '92%', maxWidth: 340,
        boxShadow: `0 24px 80px rgba(0,0,0,0.6), 0 0 40px ${zone.color}15`,
      }}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 12, height: 12, borderRadius: '50%', background: zone.color,
              boxShadow: `0 0 12px ${zone.color}` }} />
            <span style={{ fontSize: 18, fontWeight: 700, color: text,
              fontFamily: "'Space Grotesk',sans-serif" }}>{zone.label}</span>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: text3,
            fontSize: 20, cursor: 'pointer', padding: 4, fontFamily: 'inherit' }}>×</button>
        </div>

        {/* Stats row */}
        <div style={{ display: 'flex', gap: 16, marginBottom: 16 }}>
          {[
            { v: zone.stats.active, l: 'active now', c: zone.color },
            { v: zone.stats.threads, l: 'threads', c: text },
            { v: zone.stats.peak, l: 'peak hour', c: '#FFD166' },
          ].map((s, i) => (
            <div key={i} style={{ flex: 1, background: surfBg, borderRadius: 10, padding: '10px 12px',
              border: `1px solid ${darkMode ? 'rgba(42,42,64,0.5)' : 'rgba(0,0,0,0.05)'}` }}>
              <div style={{ fontSize: 22, fontWeight: 700, color: s.c, lineHeight: 1,
                fontFamily: "'Space Grotesk',sans-serif" }}>{s.v}</div>
              <div style={{ fontSize: 9, color: text3, fontFamily: "'JetBrains Mono',monospace",
                marginTop: 4, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{s.l}</div>
            </div>
          ))}
        </div>

        {/* Activity over time */}
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 10, fontWeight: 600, color: text2, marginBottom: 6,
            fontFamily: "'Space Grotesk',sans-serif", letterSpacing: '0.04em', textTransform: 'uppercase' }}>
            Activity · 24h
          </div>
          <div style={{ background: surfBg, borderRadius: 10, padding: 10,
            border: `1px solid ${darkMode ? 'rgba(42,42,64,0.5)' : 'rgba(0,0,0,0.05)'}` }}>
            <Sparkline data={zone.stats.hourly} color={zone.color} width={280} height={40} />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
              {['12a', '6a', '12p', '6p', '12a'].map((l, i) => (
                <span key={i} style={{ fontSize: 8, color: text3,
                  fontFamily: "'JetBrains Mono',monospace" }}>{l}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Weekly Heatmap */}
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 10, fontWeight: 600, color: text2, marginBottom: 6,
            fontFamily: "'Space Grotesk',sans-serif", letterSpacing: '0.04em', textTransform: 'uppercase' }}>
            Weekly Heatmap
          </div>
          <div style={{ background: surfBg, borderRadius: 10, padding: 10,
            border: `1px solid ${darkMode ? 'rgba(42,42,64,0.5)' : 'rgba(0,0,0,0.05)'}` }}>
            <HeatmapGrid data={heatData} width={280} height={42} />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
              {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d, i) => (
                <span key={i} style={{ fontSize: 7, color: text3,
                  fontFamily: "'JetBrains Mono',monospace", width: 40, textAlign: 'center' }}>{d}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Category breakdown */}
        <div>
          <div style={{ fontSize: 10, fontWeight: 600, color: text2, marginBottom: 6,
            fontFamily: "'Space Grotesk',sans-serif", letterSpacing: '0.04em', textTransform: 'uppercase' }}>
            Thread Types
          </div>
          <div style={{ background: surfBg, borderRadius: 10, padding: 10,
            border: `1px solid ${darkMode ? 'rgba(42,42,64,0.5)' : 'rgba(0,0,0,0.05)'}` }}>
            <MiniBarChart
              labels={categories.map(c => c.label)}
              values={categories.map(c => c.value)}
              colors={categories.map(c => c.color)}
              width={280} height={36}
            />
          </div>
        </div>

        {/* Tags */}
        <div style={{ display: 'flex', gap: 5, marginTop: 12, flexWrap: 'wrap' }}>
          {zone.stats.topTags.map(t => (
            <span key={t} style={{ fontSize: 10, padding: '3px 8px', borderRadius: 12,
              background: `${zone.color}15`, color: zone.color, fontWeight: 600,
              fontFamily: "'JetBrains Mono',monospace", border: `1px solid ${zone.color}33` }}>
              #{t}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Time Slider ───────────────────────────────────────────────────────
function TimeSlider({ value, onChange, darkMode }) {
  const bg = darkMode ? 'rgba(10,10,20,0.92)' : 'rgba(255,255,255,0.95)';
  const border = darkMode ? 'rgba(42,42,64,0.6)' : 'rgba(0,0,0,0.08)';
  const hourLabel = h => {
    if (h === 0) return '12a';
    if (h < 12) return `${h}a`;
    if (h === 12) return '12p';
    return `${h - 12}p`;
  };

  return (
    <div style={{
      position: 'absolute', bottom: 128, left: 14, right: 60, zIndex: 1000,
      background: bg, backdropFilter: 'blur(16px)',
      border: `1px solid ${border}`, borderRadius: 14, padding: '8px 14px',
      boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
        <span style={{ fontSize: 9, fontWeight: 600, color: darkMode ? '#A0A0BE' : '#666',
          fontFamily: "'Space Grotesk',sans-serif", letterSpacing: '0.06em', textTransform: 'uppercase' }}>
          Time
        </span>
        <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--d2c-violet)',
          fontFamily: "'JetBrains Mono',monospace" }}>
          {hourLabel(value)}
        </span>
      </div>
      <input type="range" min={0} max={23} step={1} value={value} onChange={e => onChange(+e.target.value)}
        style={{ width: '100%', accentColor: 'var(--d2c-violet)', height: 4, cursor: 'pointer' }} />
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 2 }}>
        {['12a', '6a', '12p', '6p', '12a'].map((l, i) => (
          <span key={i} style={{ fontSize: 7, color: darkMode ? '#606080' : '#bbb',
            fontFamily: "'JetBrains Mono',monospace" }}>{l}</span>
        ))}
      </div>
    </div>
  );
}

// ── Aggregate Stats Bar ───────────────────────────────────────────────
function AggregateStats({ zones, currentHour, darkMode }) {
  const totalActive = zones.reduce((a, z) => a + z.stats.hourly[currentHour], 0);
  const totalThreads = zones.reduce((a, z) => a + z.stats.threads, 0);
  const hottest = zones.reduce((a, z) => z.stats.hourly[currentHour] > a.stats.hourly[currentHour] ? z : a, zones[0]);

  const bg = darkMode ? 'rgba(10,10,20,0.92)' : 'rgba(255,255,255,0.95)';
  const border = darkMode ? 'rgba(42,42,64,0.5)' : 'rgba(0,0,0,0.06)';
  const text = darkMode ? '#F0F0F8' : '#111';
  const text2 = darkMode ? '#A0A0BE' : '#666';
  const text3 = darkMode ? '#606080' : '#999';

  return (
    <div style={{
      display: 'flex', gap: 8, padding: '0 2px', marginBottom: 10,
    }}>
      {[
        { v: totalActive, l: 'chatting', c: 'var(--d2c-cyan)', icon: '💬' },
        { v: totalThreads, l: 'threads', c: 'var(--d2c-violet)', icon: '🧵' },
        { v: hottest.label.split(' ')[0], l: 'hottest', c: hottest.color, icon: '🔥' },
      ].map((s, i) => (
        <div key={i} style={{ flex: 1, background: darkMode ? 'var(--d2c-surface)' : '#fff',
          borderRadius: 10, padding: '8px 10px',
          border: `1px solid ${border}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ fontSize: 12 }}>{s.icon}</span>
            <span style={{ fontSize: 16, fontWeight: 700, color: s.c,
              fontFamily: "'Space Grotesk',sans-serif" }}>{s.v}</span>
          </div>
          <div style={{ fontSize: 8, color: text3, fontFamily: "'JetBrains Mono',monospace",
            marginTop: 2, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{s.l}</div>
        </div>
      ))}
    </div>
  );
}

Object.assign(window, {
  MAP_ZONES, Sparkline, MiniBarChart, HeatmapGrid,
  AnalyticsCard, ZonePopover, TimeSlider, AggregateStats, getHourlyAggregate
});
