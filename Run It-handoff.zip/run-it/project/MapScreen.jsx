// ChatSpaces — Map Home Screen

const MAP_THREADS = [
  { id: 1, title: 'Anyone at the Blue Tokai right now?', tags: ['cafe', 'coffee'], active: 12, ago: '2m ago', participants: ['BraveOtter','QuietWolf','NeonFox','StormCrow','GlassHawk'], lastMessage: 'got the corner table, come find me', category: '☕', x: 0.32, y: 0.28, intensity: 'accent' },
  { id: 2, title: 'FC vs MI tonight — who\'s watching?', tags: ['sports', 'live'], active: 28, ago: '1m ago', participants: ['WildLynx','SaltRidge','IronDawn'], lastMessage: 'pub on MG road has big screen + no cover', category: '⚽', x: 0.67, y: 0.42, intensity: 'danger' },
  { id: 3, title: 'Monsoon walk anyone? Starting from Cubbon', tags: ['outdoors', 'meetup'], active: 6, ago: '5m ago', participants: ['MistPine','DuskBird'], lastMessage: 'it\'s drizzling but honestly perfect', category: '🌧️', x: 0.48, y: 0.64, intensity: 'accent' },
  { id: 4, title: 'Late night ramen — Shivajinagar area', tags: ['food', 'latenight'], active: 9, ago: '3m ago', participants: ['RedCoral','SandPeak','NightOwl'], lastMessage: 'the spot near the bus stand is still open', category: '🍜', x: 0.21, y: 0.55, intensity: 'primary' },
  { id: 5, title: 'Power cut in Indiranagar?', tags: ['local', 'help'], active: 17, ago: '4m ago', participants: ['CalmReed','StoneLeaf','AshWren','TideCliff'], lastMessage: 'yep whole sector 5 is out', category: '💡', x: 0.76, y: 0.7, intensity: 'primary' },
];

// ── City Map SVG ─────────────────────────────────────────────────────────
function CityMapSVG({ width, height, theme }) {
  const dark = theme === 'dark';
  const land = dark ? '#08080F' : '#FAFBFC';
  const block = dark ? '#0D0D19' : '#F1F5F9';
  const blockAlt = dark ? '#0B0B16' : '#EDF1F7';
  const roadMajor = dark ? '#1A1A2A' : '#E2E8F0';
  const roadMinor = dark ? '#111120' : '#EAEFF6';
  const water = dark ? '#0B1622' : '#DBEAFE';
  const park = dark ? '#0A100C' : '#DCFCE7';
  const labelColor = dark ? '#2A2A3D' : '#CBD5E1';
  const W = width, H = height;

  // Street grid definitions (normalized 0-1)
  const majH = [0.18, 0.42, 0.66, 0.88];
  const majV = [0.22, 0.5, 0.78];
  const minH = [0.06, 0.29, 0.54, 0.60, 0.76, 0.95];
  const minV = [0.08, 0.36, 0.62, 0.90];

  const px = v => v * W;
  const py = v => v * H;

  // Pre-compute blocks
  const allHLines = [...minH, ...majH].sort((a,b)=>a-b);
  const allVLines = [...minV, ...majV].sort((a,b)=>a-b);

  const blocks = [];
  for (let r = 0; r < allHLines.length - 1; r++) {
    for (let c = 0; c < allVLines.length - 1; c++) {
      const x1 = allVLines[c], x2 = allVLines[c+1];
      const y1 = allHLines[r], y2 = allHLines[r+1];
      const isMajorBlock = majH.includes(allHLines[r]) || majV.includes(allVLines[c]);
      blocks.push({ x1, y1, x2, y2, alt: (r+c)%3===0 && !isMajorBlock });
    }
  }

  // Street labels
  const streetLabels = [
    { x: 0.22, y: 0.40, text: 'MG Road', rotate: 0 },
    { x: 0.50, y: 0.14, text: 'Brigade Rd', rotate: 90 },
    { x: 0.45, y: 0.64, text: 'Cunningham', rotate: 0 },
    { x: 0.78, y: 0.40, text: 'Residency Rd', rotate: 90 },
  ];

  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ display: 'block' }}>
      {/* Background */}
      <rect width={W} height={H} fill={land} />

      {/* Blocks */}
      {blocks.map((b, i) => (
        <rect key={i}
          x={px(b.x1) + 1.5} y={py(b.y1) + 1.5}
          width={px(b.x2 - b.x1) - 3} height={py(b.y2 - b.y1) - 3}
          fill={b.alt ? blockAlt : block} />
      ))}

      {/* Water body — bottom left diagonal */}
      <path d={`M 0 ${py(0.58)} C ${px(0.08)} ${py(0.52)}, ${px(0.18)} ${py(0.60)}, ${px(0.22)} ${py(0.55)} L ${px(0.22)} ${H} L 0 ${H} Z`}
        fill={water} opacity="0.9" />
      <path d={`M 0 ${py(0.62)} C ${px(0.06)} ${py(0.58)}, ${px(0.14)} ${py(0.65)}, ${px(0.20)} ${py(0.62)}`}
        fill="none" stroke={dark ? '#0E2035' : '#BFDBFE'} strokeWidth="2" opacity="0.6" />

      {/* Park area */}
      <rect x={px(0.54)} y={py(0.10)} width={px(0.14)} height={py(0.12)} rx="4" fill={park} opacity="0.8" />

      {/* Major horizontal roads */}
      {majH.map((y, i) => (
        <rect key={`mh${i}`} x={0} y={py(y) - 3} width={W} height={6} fill={roadMajor} />
      ))}
      {/* Major vertical roads */}
      {majV.map((x, i) => (
        <rect key={`mv${i}`} x={px(x) - 3} y={0} width={6} height={H} fill={roadMajor} />
      ))}
      {/* Minor horizontal roads */}
      {minH.map((y, i) => (
        <rect key={`nih${i}`} x={0} y={py(y) - 1} width={W} height={2} fill={roadMinor} />
      ))}
      {/* Minor vertical roads */}
      {minV.map((x, i) => (
        <rect key={`niv${i}`} x={px(x) - 1} y={0} width={2} height={H} fill={roadMinor} />
      ))}
      {/* Diagonal road */}
      <line x1={px(0.08)} y1={py(0.06)} x2={px(0.50)} y2={py(0.42)} stroke={roadMajor} strokeWidth={4} />
      <line x1={px(0.50)} y1={py(0.66)} x2={px(0.78)} y2={py(0.88)} stroke={roadMinor} strokeWidth={2} />

      {/* Street labels */}
      {streetLabels.map((l, i) => (
        <text key={i} x={px(l.x)} y={py(l.y)}
          textAnchor="middle"
          fontSize={9} fill={labelColor} fontFamily="JetBrains Mono, monospace"
          transform={l.rotate ? `rotate(${l.rotate} ${px(l.x)} ${py(l.y)})` : undefined}
          style={{ pointerEvents: 'none', userSelect: 'none' }}>
          {l.text}
        </text>
      ))}
    </svg>
  );
}

// ── Hotspot Pin ───────────────────────────────────────────────────────────
function HotspotPin({ thread, onClick }) {
  const colors = {
    accent: 'var(--cs-accent)',
    primary: 'var(--cs-primary)',
    danger: 'var(--cs-danger)',
  };
  const color = colors[thread.intensity] || colors.accent;
  const [pressed, setPressed] = React.useState(false);

  return (
    <div onClick={onClick}
      onMouseDown={() => setPressed(true)} onMouseUp={() => setPressed(false)}
      style={{
        position: 'absolute',
        left: `${thread.x * 100}%`,
        top: `${thread.y * 100}%`,
        transform: `translate(-50%, -50%) scale(${pressed ? 0.9 : 1})`,
        transition: 'transform 0.15s',
        cursor: 'pointer',
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        zIndex: 10,
      }}>
      {/* Pulse rings */}
      {[0, 1, 2].map(i => (
        <div key={i} style={{
          position: 'absolute', width: 24, height: 24,
          borderRadius: '50%', border: `1.5px solid ${color}`,
          top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
          animation: 'cs-pulse-ring 2.5s ease-out infinite',
          animationDelay: `${i * 0.5}s`,
          opacity: 0,
        }} />
      ))}
      {/* Center dot */}
      <div style={{
        width: 14, height: 14, borderRadius: '50%',
        background: color,
        boxShadow: `0 0 12px ${color}`,
        position: 'relative', zIndex: 2,
      }} />
      {/* Label */}
      <div style={{
        marginTop: 4, background: 'rgba(8,8,15,0.85)',
        backdropFilter: 'blur(8px)',
        border: `1px solid ${color}33`,
        borderRadius: 'var(--cs-radius-sm)', padding: '2px 7px',
        fontSize: 11, color: 'var(--cs-text-primary)', fontWeight: 600,
        whiteSpace: 'nowrap', userSelect: 'none',
      }}>
        {thread.category} {thread.active}
      </div>
    </div>
  );
}

// ── You Are Here Pin ──────────────────────────────────────────────────────
function YouPin() {
  return (
    <div style={{
      position: 'absolute', left: '52%', top: '48%',
      transform: 'translate(-50%, -50%)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 10,
    }}>
      <div style={{
        position: 'absolute', width: 32, height: 32, borderRadius: '50%',
        background: 'var(--cs-primary)', opacity: 0.25,
        animation: 'cs-you-breathe 2s ease-in-out infinite',
      }} />
      <div style={{
        width: 16, height: 16, borderRadius: '50%',
        background: 'var(--cs-primary)',
        boxShadow: '0 0 16px var(--cs-primary)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', zIndex: 2,
      }}>
        <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#fff' }} />
      </div>
    </div>
  );
}

// ── Bottom Sheet ──────────────────────────────────────────────────────────
function BottomSheet({ onThreadSelect, activeTab, setActiveTab, searchQuery, setSearchQuery, snapState, setSnapState }) {
  const sheetRef = React.useRef(null);
  const dragStartY = React.useRef(null);
  const dragStartSnap = React.useRef(null);
  const [isDragging, setIsDragging] = React.useState(false);
  const [filterActive, setFilterActive] = React.useState('all');

  const SNAPS = { collapsed: 112, half: 0.5, full: 0.88 };

  const getHeight = (state, containerH = 600) => {
    if (state === 'collapsed') return SNAPS.collapsed;
    if (state === 'half') return Math.floor(containerH * SNAPS.half);
    return Math.floor(containerH * SNAPS.full);
  };

  const containerH = sheetRef.current?.parentElement?.offsetHeight || 600;
  const currentH = getHeight(snapState, containerH);

  const onDragStart = (clientY) => {
    dragStartY.current = clientY;
    dragStartSnap.current = snapState;
    setIsDragging(true);
  };

  const onDragEnd = (clientY) => {
    if (!isDragging) return;
    const dy = dragStartY.current - clientY;
    if (dy > 40) setSnapState(dragStartSnap.current === 'collapsed' ? 'half' : 'full');
    else if (dy < -40) setSnapState(dragStartSnap.current === 'full' ? 'half' : 'collapsed');
    setIsDragging(false);
  };

  const filteredThreads = MAP_THREADS.filter(t => {
    if (activeTab === 'hot') return t.active > 10;
    if (activeTab === 'foryou') return ['cafe', 'food', 'outdoors'].some(tag => t.tags.includes(tag));
    if (activeTab === 'search' && searchQuery) {
      return t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        t.tags.some(tag => tag.includes(searchQuery.toLowerCase()));
    }
    return true;
  });

  return (
    <div ref={sheetRef}
      style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        height: currentH,
        background: 'var(--cs-surface-deep)',
        borderRadius: '20px 20px 0 0',
        border: '1px solid var(--cs-border-subtle)',
        borderBottom: 'none',
        transition: isDragging ? 'none' : 'height 0.38s cubic-bezier(0.32,0.72,0,1)',
        display: 'flex', flexDirection: 'column',
        overflow: 'hidden',
        zIndex: 20,
        boxShadow: '0 -8px 40px rgba(0,0,0,0.4)',
        animation: 'cs-sheet-up 0.4s ease both',
      }}>
      {/* Drag Handle */}
      <div
        style={{ padding: '10px 0 6px', cursor: 'grab', flexShrink: 0, userSelect: 'none' }}
        onMouseDown={e => onDragStart(e.clientY)}
        onMouseMove={e => isDragging && e.buttons === 1 && null}
        onMouseUp={e => onDragEnd(e.clientY)}
        onTouchStart={e => onDragStart(e.touches[0].clientY)}
        onTouchEnd={e => onDragEnd(e.changedTouches[0].clientY)}
        onClick={() => setSnapState(snapState === 'collapsed' ? 'half' : snapState === 'half' ? 'full' : 'collapsed')}>
        <div style={{ width: 36, height: 4, borderRadius: 2,
          background: 'var(--cs-border-subtle)', margin: '0 auto' }} />
      </div>

      {/* Header row */}
      <div style={{ padding: '0 16px 10px', flexShrink: 0 }}>
        <div style={{ fontSize: 12, color: 'var(--cs-text-muted)', marginBottom: 8, letterSpacing: '0.04em' }}>
          around you · <span style={{ color: 'var(--cs-text-secondary)', fontWeight: 500 }}>
            {MAP_THREADS.reduce((a, t) => a + t.active, 0)} chatting
          </span>
        </div>
        {/* Tab pills */}
        <div style={{ display: 'flex', gap: 6 }}>
          {[{ id: 'all', label: '🗺 nearby' }, { id: 'hot', label: '🔥 hot' }, { id: 'foryou', label: '✨ for you' }, { id: 'search', label: '🔍' }].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              style={{
                padding: '5px 12px', borderRadius: 'var(--cs-radius-full)',
                background: activeTab === tab.id ? 'var(--cs-primary)' : 'var(--cs-surface-overlay)',
                color: activeTab === tab.id ? '#fff' : 'var(--cs-text-secondary)',
                border: `1px solid ${activeTab === tab.id ? 'var(--cs-primary)' : 'var(--cs-border-subtle)'}`,
                fontSize: 12, fontWeight: 500, cursor: 'pointer',
                transition: 'all 0.15s', fontFamily: 'inherit',
              }}>
              {tab.label}
            </button>
          ))}
        </div>
        {/* Search input */}
        {activeTab === 'search' && (
          <input
            autoFocus
            placeholder="search threads..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            style={{
              marginTop: 8, width: '100%', background: 'var(--cs-surface-overlay)',
              border: '1px solid var(--cs-border-subtle)', borderRadius: 'var(--cs-radius-md)',
              padding: '8px 14px', color: 'var(--cs-text-primary)', fontSize: 13,
              fontFamily: 'inherit', outline: 'none',
            }}
          />
        )}
      </div>

      {/* Thread list */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 16px 80px',
        scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
        <style>{`.cs-sheet-scroll::-webkit-scrollbar { display: none; }`}</style>
        <div className="cs-sheet-scroll" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {filteredThreads.map((t, i) => (
            <ThreadCard key={t.id} thread={t} index={i} onClick={() => onThreadSelect(t)} />
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Map Home Screen ───────────────────────────────────────────────────────
function MapScreen({ onThreadSelect, theme }) {
  const [snapState, setSnapState] = React.useState('collapsed');
  const [activeTab, setActiveTab] = React.useState('all');
  const [searchQuery, setSearchQuery] = React.useState('');
  const mapRef = React.useRef(null);
  const [mapSize, setMapSize] = React.useState({ w: 375, h: 400 });

  React.useEffect(() => {
    function measure() {
      if (mapRef.current) {
        const { offsetWidth, offsetHeight } = mapRef.current;
        setMapSize({ w: offsetWidth, h: offsetHeight });
      }
    }
    measure();
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, []);

  const SNAP_HEIGHTS = { collapsed: 112, half: 0.5, full: 0.88 };
  const containerH = mapRef.current?.offsetHeight || 600;
  const sheetH = snapState === 'collapsed' ? SNAP_HEIGHTS.collapsed
    : snapState === 'half' ? Math.floor(containerH * 0.5)
    : Math.floor(containerH * 0.88);
  const mapVisible = sheetH < containerH * 0.85;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%',
      background: 'var(--cs-surface-deep)', position: 'relative' }} ref={mapRef}>

      {/* Top Bar */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, zIndex: 30,
        height: 56, background: 'rgba(8,8,15,0.75)', backdropFilter: 'blur(16px)',
        borderBottom: '1px solid var(--cs-border-subtle)',
        display: 'flex', alignItems: 'center', padding: '0 16px',
        justifyContent: 'space-between',
      }}>
        <button style={{ background: 'none', border: 'none', color: 'var(--cs-text-secondary)',
          fontSize: 20, cursor: 'pointer', padding: 8, margin: -8 }}>☰</button>
        <span style={{ fontSize: 16, fontWeight: 700, color: 'var(--cs-text-primary)',
          letterSpacing: '-0.02em', fontFamily: 'Inter, sans-serif' }}>chatspaces</span>
        <div style={{ width: 36, height: 36, borderRadius: '50%',
          background: 'var(--cs-surface-overlay)', border: '1px solid var(--cs-border-subtle)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer' }}>
          <GeometricAvatar name="me" size={28} />
        </div>
      </div>

      {/* Map area */}
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0,
          opacity: mapVisible ? 1 : 0.3, transition: 'opacity 0.4s' }}>
          <CityMapSVG width={mapSize.w} height={mapSize.h} theme={theme} />
        </div>
        {/* Pins */}
        <div style={{ position: 'absolute', inset: 0 }}>
          {MAP_THREADS.map(t => (
            <HotspotPin key={t.id} thread={t} onClick={() => {
              onThreadSelect(t);
              setSnapState('half');
            }} />
          ))}
          <YouPin />
        </div>
      </div>

      {/* Bottom Sheet */}
      <BottomSheet
        onThreadSelect={onThreadSelect}
        activeTab={activeTab} setActiveTab={setActiveTab}
        searchQuery={searchQuery} setSearchQuery={setSearchQuery}
        snapState={snapState} setSnapState={setSnapState}
      />

      {/* FAB */}
      <div style={{ position: 'absolute', bottom: Math.min(sheetH + 16, containerH * 0.5), right: 16,
        transition: 'bottom 0.38s cubic-bezier(0.32,0.72,0,1)', zIndex: 25 }}>
        <FAB onClick={() => {}} />
      </div>
    </div>
  );
}

Object.assign(window, { MapScreen, MAP_THREADS });
