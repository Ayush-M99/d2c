// ChatSpaces — App Shell + Navigation

function App() {
  const [screen, setScreen] = React.useState('map');   // 'map' | 'chat'
  const [prevScreen, setPrevScreen] = React.useState(null);
  const [selectedThread, setSelectedThread] = React.useState(null);
  const [theme, setTheme] = React.useState('dark');
  const [tweaks, setTweaks] = React.useState({
    theme: 'dark',
    mapStyle: 'detailed',
    animatePins: true,
  });

  // Apply theme tokens
  React.useEffect(() => {
    window.applyCSTheme(theme);
  }, [theme]);

  // Tweaks panel protocol
  React.useEffect(() => {
    const handler = (e) => {
      if (e.data?.type === '__activate_edit_mode') setShowTweaks(true);
      if (e.data?.type === '__deactivate_edit_mode') setShowTweaks(false);
    };
    window.addEventListener('message', handler);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', handler);
  }, []);

  const [showTweaks, setShowTweaks] = React.useState(false);

  const navigateTo = (s, thread) => {
    setPrevScreen(screen);
    if (thread) setSelectedThread(thread);
    setScreen(s);
  };

  const goBack = () => {
    setScreen(prevScreen || 'map');
    setPrevScreen(null);
  };

  const handleTweakChange = (key, val) => {
    setTweaks(t => ({ ...t, [key]: val }));
    if (key === 'theme') setTheme(val);
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: { [key]: val } }, '*');
  };

  return (
    <div style={{ width: '100%', height: '100%', position: 'relative',
      fontFamily: 'Inter, sans-serif', overflow: 'hidden',
      background: 'var(--cs-surface-deep)', color: 'var(--cs-text-primary)' }}>

      <GlobalStyles />

      {/* Screens */}
      <div style={{ width: '100%', height: '100%', position: 'relative' }}>
        {screen === 'map' && (
          <MapScreen
            theme={theme}
            onThreadSelect={(t) => navigateTo('chat', t)}
          />
        )}
        {screen === 'chat' && (
          <ChatScreen
            thread={selectedThread}
            onBack={goBack}
          />
        )}
      </div>

      {/* Tweaks Panel */}
      {showTweaks && (
        <TweaksPanel onClose={() => {
          setShowTweaks(false);
          window.parent.postMessage({ type: '__edit_mode_dismissed' }, '*');
        }}>
          <TweakSection title="Theme">
            <TweakRadio
              label="Color Mode"
              value={tweaks.theme}
              options={[
                { label: 'Dark', value: 'dark' },
                { label: 'Light', value: 'light' },
              ]}
              onChange={v => handleTweakChange('theme', v)}
            />
          </TweakSection>
          <TweakSection title="Map">
            <TweakToggle
              label="Animate pins"
              value={tweaks.animatePins}
              onChange={v => handleTweakChange('animatePins', v)}
            />
            <TweakRadio
              label="Map style"
              value={tweaks.mapStyle}
              options={[
                { label: 'Detailed', value: 'detailed' },
                { label: 'Minimal', value: 'minimal' },
              ]}
              onChange={v => handleTweakChange('mapStyle', v)}
            />
          </TweakSection>
          <TweakSection title="Navigate">
            <TweakButton label="→ Map Home" onClick={() => setScreen('map')} />
            <TweakButton label="→ Chat View" onClick={() => {
              setSelectedThread(MAP_THREADS[0]);
              setScreen('chat');
            }} />
          </TweakSection>
        </TweaksPanel>
      )}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
