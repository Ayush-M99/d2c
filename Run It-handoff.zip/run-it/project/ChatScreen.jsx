// ChatSpaces — Thread Chat View

const NAME_COLORS = [
  '#6366F1','#22D3EE','#10B981','#F59E0B','#EC4899','#8B5CF6','#14B8A6','#F97316'
];

function nameColor(name) {
  const h = hashStr(name || 'x');
  return NAME_COLORS[h % NAME_COLORS.length];
}

const INITIAL_MESSAGES = [
  { id: 1, from: 'BraveOtter', text: 'yo who\'s downstairs at blue tokai rn', time: '2:41p', mine: false },
  { id: 2, from: 'NeonFox', text: 'me! been here since 10. corner booth near the window', time: '2:42p', mine: false },
  { id: 3, from: 'me', text: 'omw, 5 mins. save me a spot?', time: '2:43p', mine: true },
  { id: 4, from: 'BraveOtter', text: 'we\'re 4 already but there\'s a big table free', time: '2:43p', mine: false },
  { id: 5, type: 'system', text: 'QuietWolf joined' },
  { id: 6, from: 'QuietWolf', text: 'which floor is everyone on?', time: '2:44p', mine: false },
  { id: 7, from: 'NeonFox', text: 'ground, by the espresso bar', time: '2:44p', mine: false },
  { id: 8, type: 'image', from: 'BraveOtter', time: '2:45p', mine: false, caption: 'the vibe rn' },
];

const INCOMING = [
  { from: 'QuietWolf', text: 'ok I can see you guys', delay: 4000 },
  { from: 'BraveOtter', text: 'the filter coffee here is actually insane today', delay: 9000 },
  { from: 'NeonFox', text: 'monsoon makes it hit different fr', delay: 14000 },
  { from: 'StormCrow', text: 'anyone want to pool a cab to koramangala after?', delay: 20000 },
];

// ── View-Once Image ───────────────────────────────────────────────────────
function ViewOnceImage({ caption, onViewed }) {
  const [state, setState] = React.useState('idle'); // idle | revealing | counting | dissolving | viewed
  const [count, setCount] = React.useState(8);
  const containerRef = React.useRef(null);

  const handleTap = () => {
    if (state === 'idle') {
      setState('revealing');
      setTimeout(() => {
        setState('counting');
        let c = 8;
        const interval = setInterval(() => {
          c--;
          setCount(c);
          if (c <= 0) {
            clearInterval(interval);
            setState('dissolving');
            setTimeout(() => { setState('viewed'); onViewed && onViewed(); }, 1000);
          }
        }, 1000);
      }, 900);
    } else if (state === 'counting') {
      setState('dissolving');
      setTimeout(() => { setState('viewed'); onViewed && onViewed(); }, 900);
    }
  };

  if (state === 'viewed') {
    return (
      <div style={{ width: 180, height: 120, borderRadius: 'var(--cs-radius-md)',
        background: 'var(--cs-surface-overlay)', border: '1px solid var(--cs-border-subtle)',
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        gap: 4 }}>
        <span style={{ fontSize: 18, opacity: 0.4 }}>👁</span>
        <span style={{ fontSize: 11, color: 'var(--cs-text-muted)' }}>viewed</span>
      </div>
    );
  }

  // Progress ring for countdown
  const circumference = 2 * Math.PI * 54;
  const dashOffset = state === 'counting' ? circumference * (count / 8) : circumference;
  const isRevealing = state === 'revealing';
  const isCounting = state === 'counting';
  const isDissolving = state === 'dissolving';

  return (
    <div onClick={handleTap} ref={containerRef} style={{
      width: 200, height: 200, position: 'relative',
      cursor: state === 'idle' ? 'pointer' : 'default',
      borderRadius: 'var(--cs-radius-md)', overflow: 'hidden',
    }}>
      {/* Fake photo content — revealed in quadrants */}
      <div style={{
        position: 'absolute', inset: 0, overflow: 'hidden',
        borderRadius: 'var(--cs-radius-md)',
      }}>
        {/* Simulated photo */}
        <div style={{ position: 'absolute', inset: 0,
          background: 'linear-gradient(135deg, #1a1a2e 0%, #0d1b2a 40%, #16213e 70%, #0f3460 100%)',
          display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {/* Fake cafe scene */}
          <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: '40%',
            background: 'rgba(139,90,43,0.3)' }} />
          <div style={{ position: 'absolute', top: '30%', left: '20%', width: 8, height: 40,
            background: 'rgba(255,200,100,0.6)', borderRadius: 4 }} />
          <div style={{ position: 'absolute', top: '30%', right: '25%', width: 8, height: 35,
            background: 'rgba(255,200,100,0.5)', borderRadius: 4 }} />
          <div style={{ fontSize: 32, opacity: 0.6 }}>☕</div>
        </div>

        {/* Origami panels — 4 quadrants that unfold */}
        {[
          { id: 'tl', origin: '100% 100%', style: { top:0, left:0, width:'50%', height:'50%' } },
          { id: 'tr', origin: '0% 100%', style: { top:0, right:0, width:'50%', height:'50%' } },
          { id: 'bl', origin: '100% 0%', style: { bottom:0, left:0, width:'50%', height:'50%' } },
          { id: 'br', origin: '0% 0%', style: { bottom:0, right:0, width:'50%', height:'50%' } },
        ].map((panel, i) => {
          const unfolded = isRevealing || isCounting || isDissolving;
          const delay = `${i * 0.18}s`;
          return (
            <div key={panel.id} style={{
              position: 'absolute', ...panel.style,
              background: 'var(--cs-surface-elevated)',
              backdropFilter: 'blur(20px)',
              transformOrigin: panel.origin,
              transform: unfolded ? 'rotateY(90deg) rotateX(90deg)' : 'none',
              transition: unfolded ? `transform 0.45s cubic-bezier(0.34,1.2,0.64,1) ${delay}` : 'none',
              opacity: isDissolving ? 0 : 1,
              zIndex: 5,
            }} />
          );
        })}

        {/* Blur overlay for idle state */}
        <div style={{
          position: 'absolute', inset: 0,
          backdropFilter: isRevealing || isCounting || isDissolving ? 'blur(0px)' : 'blur(16px)',
          transition: 'backdrop-filter 0.4s',
          zIndex: 3,
        }} />

        {/* Dissolve overlay */}
        {isDissolving && (
          <div style={{
            position: 'absolute', inset: 0, zIndex: 10,
            background: 'var(--cs-surface-deep)',
            animation: 'cs-fadein 0.9s ease forwards',
          }} />
        )}
      </div>

      {/* Idle label */}
      {state === 'idle' && (
        <div style={{ position: 'absolute', inset: 0, zIndex: 10,
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          gap: 6 }}>
          <div style={{ fontSize: 28 }}>👁</div>
          <div style={{ fontSize: 12, color: 'var(--cs-text-secondary)', fontWeight: 500 }}>view once</div>
          <div style={{ fontSize: 11, color: 'var(--cs-text-muted)' }}>{caption}</div>
        </div>
      )}

      {/* Countdown ring */}
      {isCounting && (
        <div style={{ position: 'absolute', top: 8, left: '50%', transform: 'translateX(-50%)',
          zIndex: 15, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg width={28} height={28} style={{ transform: 'rotate(-90deg)' }}>
            <circle cx={14} cy={14} r={10} fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth={2.5} />
            <circle cx={14} cy={14} r={10} fill="none"
              stroke="var(--cs-danger)" strokeWidth={2.5}
              strokeDasharray={2 * Math.PI * 10}
              strokeDashoffset={(2 * Math.PI * 10) * (1 - count / 8)}
              strokeLinecap="round"
              style={{ transition: 'stroke-dashoffset 0.9s linear' }} />
          </svg>
          <span style={{ position: 'absolute', fontSize: 10, fontWeight: 700,
            color: '#fff', fontFamily: 'JetBrains Mono, monospace', transform: 'rotate(90deg)' }}>
            {count}
          </span>
        </div>
      )}

      {/* Screenshot disabled pill */}
      {isCounting && (
        <div style={{ position: 'absolute', bottom: 10, left: '50%', transform: 'translateX(-50%)',
          zIndex: 15, background: 'rgba(0,0,0,0.6)', borderRadius: 'var(--cs-radius-full)',
          padding: '3px 10px', fontSize: 10, color: 'var(--cs-text-muted)', whiteSpace: 'nowrap' }}>
          screenshot disabled
        </div>
      )}
    </div>
  );
}

// ── Message Bubble ────────────────────────────────────────────────────────
function MessageBubble({ msg, showName, isLast }) {
  const [showTime, setShowTime] = React.useState(false);
  const color = nameColor(msg.from);

  if (msg.type === 'system') {
    return (
      <div style={{ textAlign: 'center', padding: '6px 0',
        animation: 'cs-fadein 0.3s ease both' }}>
        <span style={{ fontSize: 11, color: 'var(--cs-text-muted)',
          background: 'var(--cs-surface-overlay)', padding: '3px 12px',
          borderRadius: 'var(--cs-radius-full)' }}>
          {msg.text}
        </span>
      </div>
    );
  }

  const isImage = msg.type === 'image';
  return (
    <div style={{
      display: 'flex', flexDirection: 'column',
      alignItems: msg.mine ? 'flex-end' : 'flex-start',
      marginBottom: isLast ? 4 : 2,
      animation: 'cs-bubble-in 0.22s ease both',
      animationDelay: isLast ? '0ms' : '0ms',
    }}>
      {showName && !msg.mine && (
        <span style={{ fontSize: 11, fontWeight: 600, marginBottom: 3, marginLeft: 4,
          color, letterSpacing: '0.01em' }}>
          {msg.from}
        </span>
      )}
      <div
        onMouseEnter={() => setShowTime(true)}
        onMouseLeave={() => setShowTime(false)}
        style={{
          maxWidth: isImage ? 'auto' : '75%',
          background: isImage ? 'none' : msg.mine
            ? 'rgba(99,102,241,0.22)' : 'var(--cs-surface-elevated)',
          border: isImage ? 'none' : `1px solid ${msg.mine ? 'rgba(99,102,241,0.3)' : 'var(--cs-border-subtle)'}`,
          borderRadius: msg.mine
            ? 'var(--cs-radius-md) var(--cs-radius-md) var(--cs-radius-sm) var(--cs-radius-md)'
            : 'var(--cs-radius-md) var(--cs-radius-md) var(--cs-radius-md) var(--cs-radius-sm)',
          padding: isImage ? 0 : '9px 13px',
          fontSize: 14, color: 'var(--cs-text-primary)', lineHeight: 1.5,
          cursor: 'default',
        }}>
        {isImage ? <ViewOnceImage caption={msg.caption} /> : msg.text}
      </div>
      {(showTime || isLast) && msg.time && (
        <span style={{ fontSize: 10, color: 'var(--cs-text-muted)', marginTop: 2,
          fontFamily: 'JetBrains Mono, monospace',
          marginLeft: msg.mine ? 0 : 4, marginRight: msg.mine ? 4 : 0,
          opacity: showTime ? 1 : 0.6, transition: 'opacity 0.15s' }}>
          {msg.time}
        </span>
      )}
    </div>
  );
}

// ── Chat Screen ────────────────────────────────────────────────────────────
function ChatScreen({ thread, onBack }) {
  const [messages, setMessages] = React.useState(INITIAL_MESSAGES);
  const [input, setInput] = React.useState('');
  const [isTyping, setIsTyping] = React.useState(false);
  const [typingName, setTypingName] = React.useState('');
  const [toast, setToast] = React.useState({ visible: false, msg: '', type: 'info' });
  const listRef = React.useRef(null);
  const inputRef = React.useRef(null);
  const incomingIdx = React.useRef(0);

  const scrollToBottom = () => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight;
    }
  };

  React.useEffect(() => { scrollToBottom(); }, [messages]);

  // Simulate incoming messages
  React.useEffect(() => {
    const timers = INCOMING.map((inc, i) => {
      const t1 = setTimeout(() => {
        setTypingName(inc.from);
        setIsTyping(true);
      }, inc.delay - 1500);
      const t2 = setTimeout(() => {
        setIsTyping(false);
        setMessages(prev => [...prev, {
          id: Date.now() + i,
          from: inc.from, text: inc.text,
          time: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }).replace(':0', ':').toLowerCase().replace(' ', ''),
          mine: false,
        }]);
      }, inc.delay);
      return [t1, t2];
    });
    return () => timers.flat().forEach(clearTimeout);
  }, []);

  const sendMessage = () => {
    if (!input.trim()) return;
    setMessages(prev => [...prev, {
      id: Date.now(), from: 'me', text: input.trim(),
      time: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }).replace(' ', '').toLowerCase(),
      mine: true,
    }]);
    setInput('');
  };

  const showToast = (msg, type = 'info') => {
    setToast({ visible: true, msg, type });
    setTimeout(() => setToast(t => ({ ...t, visible: false })), 2500);
  };

  const activeThread = thread || MAP_THREADS[0];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%',
      background: 'var(--cs-surface-deep)', position: 'relative',
      animation: 'cs-slide-in-right 0.28s cubic-bezier(0.32,0.72,0,1) both' }}>

      <Toast visible={toast.visible} message={toast.msg} type={toast.type} />

      {/* Header */}
      <div style={{
        height: 60, padding: '0 12px',
        background: 'rgba(8,8,15,0.85)', backdropFilter: 'blur(16px)',
        borderBottom: '1px solid var(--cs-border-subtle)',
        display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0,
      }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none',
          color: 'var(--cs-primary)', fontSize: 22, cursor: 'pointer',
          padding: '4px 8px', margin: -4, fontFamily: 'inherit',
          display: 'flex', alignItems: 'center', gap: 4 }}>
          ←
        </button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--cs-text-primary)',
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {activeThread.category} {activeThread.title}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 1 }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%',
              background: 'var(--cs-success)',
              boxShadow: '0 0 5px var(--cs-success)' }} />
            <span style={{ fontSize: 11, color: 'var(--cs-text-muted)',
              fontFamily: 'JetBrains Mono, monospace' }}>
              {activeThread.active} active
            </span>
          </div>
        </div>
        <button onClick={() => showToast('thread options', 'info')}
          style={{ background: 'none', border: 'none',
            color: 'var(--cs-text-muted)', fontSize: 20, cursor: 'pointer',
            padding: 6, fontFamily: 'inherit' }}>
          ⋯
        </button>
      </div>

      {/* Messages */}
      <div ref={listRef} style={{ flex: 1, overflowY: 'auto', padding: '12px 14px',
        display: 'flex', flexDirection: 'column', gap: 6,
        scrollbarWidth: 'none' }}>
        {messages.map((msg, i) => {
          const prev = messages[i - 1];
          const showName = !msg.mine && (!prev || prev.from !== msg.from || prev.type === 'system');
          return (
            <MessageBubble key={msg.id} msg={msg} showName={showName} isLast={i === messages.length - 1} />
          );
        })}
        {isTyping && <TypingIndicator name={typingName} />}
      </div>

      {/* Composer */}
      <div style={{
        padding: '10px 12px 16px', borderTop: '1px solid var(--cs-border-subtle)',
        background: 'var(--cs-surface-deep)', flexShrink: 0,
      }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end',
          background: 'var(--cs-surface-overlay)',
          borderRadius: 'var(--cs-radius-lg)',
          border: '1px solid var(--cs-border-subtle)',
          padding: '8px 8px 8px 12px' }}>
          <button onClick={() => showToast('attach image', 'info')}
            style={{ background: 'none', border: 'none', color: 'var(--cs-text-muted)',
              fontSize: 18, cursor: 'pointer', padding: 4, flexShrink: 0, fontFamily: 'inherit' }}>
            📎
          </button>
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => {
              setInput(e.target.value);
              e.target.style.height = 'auto';
              e.target.style.height = Math.min(e.target.scrollHeight, 100) + 'px';
            }}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
            placeholder="type a message…"
            rows={1}
            style={{
              flex: 1, background: 'none', border: 'none', resize: 'none',
              color: 'var(--cs-text-primary)', fontSize: 14, fontFamily: 'Inter, sans-serif',
              outline: 'none', maxHeight: 100, overflowY: 'auto',
              lineHeight: 1.5, scrollbarWidth: 'none',
            }}
          />
          <button onClick={sendMessage}
            style={{
              width: 36, height: 36, borderRadius: '50%', flexShrink: 0,
              background: input.trim() ? 'var(--cs-primary)' : 'var(--cs-surface-elevated)',
              border: 'none', color: input.trim() ? '#fff' : 'var(--cs-text-muted)',
              fontSize: 16, cursor: input.trim() ? 'pointer' : 'default',
              transition: 'all 0.2s', display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: input.trim() ? 'var(--cs-glow-primary)' : 'none',
              fontFamily: 'inherit',
            }}>
            ➤
          </button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ChatScreen });
