// d2c — Real Map with Leaflet + OSM tiles, dark/light toggle, interactive pins

// Leaflet CSS injected
const LEAFLET_CSS = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
const LEAFLET_JS = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';

// Bangalore coordinates for threads
const D2C_THREADS = [
  { id:1, title:'Blue Tokai — anyone here?', tags:['cafe','coffee'], active:14, ago:'now', participants:['BraveOtter','QuietWolf','NeonFox','StormCrow','GlassHawk'], lastMessage:'got the corner table, filter coffee is crazy today', emoji:'☕', zone:'food', lat:12.9730, lng:77.6060 },
  { id:2, title:'FC vs MI watch party', tags:['sports','live'], active:32, ago:'1m', participants:['WildLynx','SaltRidge','IronDawn'], lastMessage:'pub on MG road, big screen, no cover', emoji:'⚽', zone:'nightlife', lat:12.9750, lng:77.6190 },
  { id:3, title:'Monsoon walk from Cubbon', tags:['outdoors','walk'], active:8, ago:'3m', participants:['MistPine','DuskBird'], lastMessage:'drizzling but honestly perfect for it', emoji:'🌧', zone:'outdoors', lat:12.9763, lng:77.5929 },
  { id:4, title:'Late night ramen — Shivaji', tags:['food','latenight'], active:11, ago:'2m', participants:['RedCoral','SandPeak','NightOwl'], lastMessage:'spot near the bus stand still open', emoji:'🍜', zone:'food', lat:12.9810, lng:77.6050 },
  { id:5, title:'Power cut Indiranagar?', tags:['local','help'], active:22, ago:'4m', participants:['CalmReed','StoneLeaf','AshWren','TideCliff'], lastMessage:'yep whole sector 5 is out again', emoji:'💡', zone:'transit', lat:12.9784, lng:77.6408 },
  { id:6, title:'Open mic at Fandom tonight', tags:['music','culture'], active:19, ago:'5m', participants:['VoidPulse','SilkRain','NightBloom'], lastMessage:'starts at 9, get there early for seats', emoji:'🎤', zone:'culture', lat:12.9680, lng:77.5980 },
  { id:7, title:'Pottery class — Commercial St', tags:['art','workshop'], active:5, ago:'8m', participants:['ClayHand','GoldSpark'], lastMessage:'₹500 for 2 hours, really therapeutic', emoji:'🏺', zone:'culture', lat:12.9830, lng:77.6080 },
];

const ZONE_COLORS = {
  food:'#FF6B35', nightlife:'#FF3CAC', culture:'#8B5CF6',
  outdoors:'#06D6A0', transit:'#4CC9F0',
};

const ZONES_META = [
  { id:'food', label:'Food & Drink', emoji:'🍽' },
  { id:'nightlife', label:'Nightlife', emoji:'🌃' },
  { id:'culture', label:'Arts & Culture', emoji:'🎨' },
  { id:'outdoors', label:'Parks & Outdoors', emoji:'🌿' },
  { id:'transit', label:'Transit & Local', emoji:'🚌' },
];

// ── Leaflet Map Component ─────────────────────────────────────────────
function LeafletMap({ darkMode, onThreadSelect, layers }) {
  const mapContainerRef = React.useRef(null);
  const mapRef = React.useRef(null);
  const markersRef = React.useRef([]);
  const tileRef = React.useRef(null);
  const youMarkerRef = React.useRef(null);

  const DARK_TILES = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
  const LIGHT_TILES = 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';

  // Center: MG Road area, Bangalore
  const CENTER = [12.9750, 77.6100];
  const ZOOM = 15;

  // You location
  const YOU = [12.9745, 77.6080];

  // Init map
  React.useEffect(() => {
    if (!window.L || mapRef.current) return;
    const map = window.L.map(mapContainerRef.current, {
      center: CENTER,
      zoom: ZOOM,
      zoomControl: false,
      attributionControl: false,
    });
    mapRef.current = map;

    // Tile layer
    tileRef.current = window.L.tileLayer(darkMode ? DARK_TILES : LIGHT_TILES, {
      maxZoom: 19,
      subdomains: 'abcd',
    }).addTo(map);

    // "You" marker
    const youIcon = window.L.divIcon({
      className: '',
      html: `<div class="d2c-you-pin"><div class="d2c-you-ring"></div><div class="d2c-you-dot"><div class="d2c-you-inner"></div></div></div>`,
      iconSize: [40, 40],
      iconAnchor: [20, 20],
    });
    youMarkerRef.current = window.L.marker(YOU, { icon: youIcon, interactive: false }).addTo(map);

    return () => { map.remove(); mapRef.current = null; };
  }, []);

  // Update tiles on theme change
  React.useEffect(() => {
    if (!mapRef.current || !tileRef.current) return;
    tileRef.current.setUrl(darkMode ? DARK_TILES : LIGHT_TILES);
  }, [darkMode]);

  // Update markers
  React.useEffect(() => {
    if (!mapRef.current) return;
    // Clear old markers
    markersRef.current.forEach(m => m.remove());
    markersRef.current = [];

    const visibleThreads = D2C_THREADS.filter(t => layers[t.zone]);

    visibleThreads.forEach(thread => {
      const color = ZONE_COLORS[thread.zone] || '#8B5CF6';
      const isHot = thread.active > 20;
      const size = isHot ? 44 : 38;

      const html = `
        <div class="d2c-pin-wrap" style="--pin-color:${color}">
          <div class="d2c-pin-pulse"></div>
          <div class="d2c-pin-pulse d2c-pin-pulse-2"></div>
          <div class="d2c-pin-core" style="width:${isHot?16:12}px;height:${isHot?16:12}px">
            ${isHot ? '<div class="d2c-pin-hot-ring"></div>' : ''}
          </div>
          <div class="d2c-pin-label">
            <span class="d2c-pin-emoji">${thread.emoji}</span>
            <span class="d2c-pin-count">${thread.active}</span>
          </div>
        </div>
      `;

      const icon = window.L.divIcon({
        className: '',
        html: html,
        iconSize: [size, size + 24],
        iconAnchor: [size/2, size/2],
      });

      const marker = window.L.marker([thread.lat, thread.lng], { icon }).addTo(mapRef.current);
      marker.on('click', () => onThreadSelect(thread));
      markersRef.current.push(marker);
    });
  }, [layers, onThreadSelect]);

  // Recenter button
  const recenter = () => {
    if (mapRef.current) mapRef.current.flyTo(CENTER, ZOOM, { duration: 0.8 });
  };

  return (
    <div style={{position:'absolute',inset:0}}>
      <div ref={mapContainerRef} style={{width:'100%',height:'100%'}}></div>
      {/* Recenter button */}
      <button onClick={recenter}
        style={{position:'absolute',bottom:140,right:14,zIndex:1000,
          width:40,height:40,borderRadius:'50%',
          background:darkMode?'rgba(10,10,18,0.92)':'rgba(255,255,255,0.95)',
          backdropFilter:'blur(12px)',
          border:`1px solid ${darkMode?'rgba(42,42,64,0.8)':'rgba(0,0,0,0.1)'}`,
          color:darkMode?'var(--d2c-text)':'#333',
          fontSize:18,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',
          boxShadow:'0 2px 12px rgba(0,0,0,0.3)',fontFamily:'inherit'}}>
        ⌖
      </button>
    </div>
  );
}

// ── Layer Control v2 ──────────────────────────────────────────────────
function LayerControl2({ layers, setLayers, darkMode }) {
  const [expanded, setExpanded] = React.useState(false);
  return (
    <div style={{position:'absolute',top:62,left:10,zIndex:1000,
      display:'flex',flexDirection:'column',gap:4}}>
      {/* Toggle button */}
      <button onClick={()=>setExpanded(!expanded)}
        style={{display:'flex',alignItems:'center',gap:6,
          background:darkMode?'rgba(10,10,18,0.92)':'rgba(255,255,255,0.95)',
          backdropFilter:'blur(12px)',
          border:`1px solid ${darkMode?'rgba(42,42,64,0.8)':'rgba(0,0,0,0.1)'}`,
          borderRadius:'var(--d2c-r-full)',padding:'7px 12px',cursor:'pointer',
          boxShadow:'0 2px 12px rgba(0,0,0,0.2)',fontFamily:'inherit',
          color:darkMode?'var(--d2c-text)':'#333',fontSize:12,fontWeight:600}}>
        <span style={{fontSize:14}}>🗺</span>
        <span style={{fontFamily:"'Space Grotesk',sans-serif"}}>Layers</span>
        <span style={{fontSize:10,transform:expanded?'rotate(180deg)':'rotate(0)',transition:'transform 0.2s'}}>▾</span>
      </button>
      {/* Layer pills */}
      {expanded && ZONES_META.map(z => {
        const active = layers[z.id];
        const color = ZONE_COLORS[z.id];
        return (
          <button key={z.id}
            onClick={() => setLayers(l => ({...l, [z.id]: !l[z.id]}))}
            style={{display:'flex',alignItems:'center',gap:6,
              background: active
                ? (darkMode ? `${color}18` : `${color}15`)
                : (darkMode ? 'rgba(10,10,18,0.88)' : 'rgba(255,255,255,0.92)'),
              backdropFilter:'blur(12px)',
              border:`1px solid ${active ? color+'55' : darkMode?'rgba(42,42,64,0.6)':'rgba(0,0,0,0.08)'}`,
              borderRadius:'var(--d2c-r-full)',padding:'5px 10px',
              cursor:'pointer',transition:'all 0.2s',
              boxShadow: active ? `0 0 12px ${color}22` : '0 1px 6px rgba(0,0,0,0.1)',
              fontFamily:'inherit'}}>
            <span style={{fontSize:12}}>{z.emoji}</span>
            <span style={{fontSize:10,fontWeight:600,
              color: active ? color : (darkMode?'var(--d2c-text-3)':'#888'),
              fontFamily:"'Space Grotesk',sans-serif"}}>
              {z.label}
            </span>
            <div style={{width:8,height:8,borderRadius:'50%',
              background: active ? color : (darkMode?'var(--d2c-border)':'#ccc'),
              boxShadow: active ? `0 0 6px ${color}` : 'none',
              transition:'all 0.2s'}}/>
          </button>
        );
      })}
    </div>
  );
}

// ── Bottom Sheet v3 ───────────────────────────────────────────────────
function Sheet3({ threads, onSelect, snapState, setSnapState, darkMode }) {
  const [tab, setTab] = React.useState('nearby');
  const [search, setSearch] = React.useState('');

  const filtered = threads.filter(t => {
    if (tab === 'hot') return t.active > 10;
    if (tab === 'foryou') return ['food','culture','outdoors'].includes(t.zone);
    if (tab === 'search' && search) return t.title.toLowerCase().includes(search.toLowerCase()) || t.tags.some(tag=>tag.includes(search.toLowerCase()));
    return true;
  });

  const SNAPS = { collapsed: 118, half: '50%', full: '88%' };
  const h = SNAPS[snapState];

  const bg = darkMode ? 'rgba(10,10,18,0.96)' : 'rgba(255,255,255,0.97)';
  const border = darkMode ? 'var(--d2c-border)' : 'rgba(0,0,0,0.08)';
  const textCol = darkMode ? 'var(--d2c-text)' : '#111';
  const text2Col = darkMode ? 'var(--d2c-text-2)' : '#555';
  const text3Col = darkMode ? 'var(--d2c-text-3)' : '#999';
  const surfaceCol = darkMode ? 'var(--d2c-surface-2)' : '#F5F5F8';
  const cardBg = darkMode ? 'var(--d2c-surface)' : '#fff';
  const cardBorder = darkMode ? 'var(--d2c-border)' : 'rgba(0,0,0,0.06)';

  return (
    <div style={{position:'absolute',bottom:0,left:0,right:0,height:h,
      background:bg,backdropFilter:'blur(24px)',
      borderRadius:'22px 22px 0 0',
      border:`1px solid ${border}`,borderBottom:'none',
      transition:'height 0.4s cubic-bezier(0.32,0.72,0,1)',
      display:'flex',flexDirection:'column',overflow:'hidden',zIndex:1001,
      boxShadow:darkMode ? '0 -12px 60px rgba(0,0,0,0.6)' : '0 -8px 40px rgba(0,0,0,0.08)'}}>

      {/* Handle */}
      <div style={{padding:'10px 0 6px',cursor:'pointer',flexShrink:0,userSelect:'none'}}
        onClick={()=>setSnapState(s=>s==='collapsed'?'half':s==='half'?'full':'collapsed')}>
        <div style={{width:36,height:4,borderRadius:2,
          background:darkMode?'linear-gradient(90deg,var(--d2c-violet),var(--d2c-pink))':'rgba(0,0,0,0.15)',
          margin:'0 auto',opacity:darkMode?0.5:1}}/>
      </div>

      {/* Header */}
      <div style={{padding:'0 16px 10px',flexShrink:0}}>
        <div style={{fontSize:12,color:text3Col,marginBottom:8,
          fontFamily:"'JetBrains Mono',monospace",letterSpacing:'0.04em'}}>
          around you · <span style={{color:'var(--d2c-cyan)',fontWeight:600}}>
            {threads.reduce((a,t)=>a+t.active,0)} chatting
          </span>
        </div>
        <div style={{display:'flex',gap:5,overflow:'auto',scrollbarWidth:'none'}}>
          {[{id:'nearby',l:'🗺 nearby'},{id:'hot',l:'🔥 hot'},{id:'foryou',l:'✨ for you'},{id:'search',l:'🔍'}].map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)}
              style={{padding:'6px 14px',borderRadius:'var(--d2c-r-full)',
                background:tab===t.id?'var(--d2c-violet)':surfaceCol,
                color:tab===t.id?'#fff':text2Col,
                border:tab===t.id?'none':`1px solid ${cardBorder}`,
                fontSize:12,fontWeight:600,cursor:'pointer',transition:'all 0.18s',
                fontFamily:"'Space Grotesk',sans-serif",whiteSpace:'nowrap',
                boxShadow:tab===t.id?'0 0 16px var(--d2c-violet-glow)':'none'}}>
              {t.l}
            </button>
          ))}
        </div>
        {tab==='search' && <input autoFocus placeholder="search threads, places..." value={search}
          onChange={e=>setSearch(e.target.value)}
          style={{marginTop:8,width:'100%',background:surfaceCol,
            border:`1px solid ${cardBorder}`,borderRadius:'var(--d2c-r-md)',
            padding:'9px 14px',color:textCol,fontSize:13,
            fontFamily:"'DM Sans',sans-serif",outline:'none'}}/>}
      </div>

      {/* Thread list */}
      <div style={{flex:1,overflowY:'auto',padding:'0 14px 80px',scrollbarWidth:'none'}}>
        <div style={{display:'flex',flexDirection:'column',gap:10}}>
          {filtered.map((t,i)=>(
            <ThreadCard3 key={t.id} thread={t} index={i} onClick={()=>onSelect(t)} darkMode={darkMode}/>
          ))}
          {filtered.length===0 && <div style={{textAlign:'center',padding:'32px 0',color:text3Col,fontSize:13}}>no threads here yet</div>}
        </div>
      </div>
    </div>
  );
}

// ── Thread Card v3 (theme-aware) ──────────────────────────────────────
function ThreadCard3({ thread, onClick, index=0, darkMode }) {
  const [hov, setHov] = React.useState(false);
  const zoneColor = ZONE_COLORS[thread.zone] || '#8B5CF6';
  const isHot = thread.active > 20;
  const cardBg = darkMode ? (hov?'var(--d2c-surface-2)':'var(--d2c-surface)') : (hov?'#F0F0F5':'#fff');
  const cardBorder = darkMode ? 'var(--d2c-border)' : 'rgba(0,0,0,0.06)';
  const textCol = darkMode ? 'var(--d2c-text)' : '#111';
  const text2Col = darkMode ? 'var(--d2c-text-2)' : '#555';
  const text3Col = darkMode ? 'var(--d2c-text-3)' : '#999';

  return (
    <div onClick={onClick}
      onPointerEnter={()=>setHov(true)} onPointerLeave={()=>setHov(false)}
      style={{
        background:cardBg,
        border:`1px solid ${hov ? zoneColor+'55' : cardBorder}`,
        borderRadius:'var(--d2c-r-md)',padding:'14px 16px',cursor:'pointer',
        position:'relative',overflow:'hidden',
        transform:hov?'translateY(-2px) scale(1.005)':'none',
        boxShadow:hov?`0 8px 32px ${zoneColor}15, 0 0 0 1px ${zoneColor}22`:'0 1px 4px rgba(0,0,0,0.04)',
        transition:'all 0.22s cubic-bezier(0.34,1.2,0.64,1)',
      }}>
      <div style={{position:'absolute',top:0,left:0,width:3,height:'100%',
        background:`linear-gradient(180deg,${zoneColor},transparent)`,borderRadius:'0 2px 2px 0'}}/>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',gap:12}}>
        <div style={{flex:1,minWidth:0,paddingLeft:6}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
            <span style={{fontSize:17}}>{thread.emoji}</span>
            <span style={{fontSize:15,fontWeight:700,color:textCol,lineHeight:1.3,
              fontFamily:"'Space Grotesk',sans-serif"}}>{thread.title}</span>
          </div>
          <div style={{display:'flex',flexWrap:'wrap',gap:4,marginBottom:8}}>
            {thread.tags.map(t=><Pill key={t} label={`#${t}`} color={zoneColor} small/>)}
            {isHot && <Pill label="🔥 hot" color="var(--d2c-red)" glow small/>}
          </div>
          <div style={{fontSize:13,color:text2Col,fontStyle:'italic',
            overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
            "{thread.lastMessage}"
          </div>
        </div>
        <AvatarStack names={thread.participants} size={26}/>
      </div>
      <div style={{marginTop:10,display:'flex',alignItems:'center',gap:8,paddingLeft:6}}>
        <div style={{display:'flex',alignItems:'center',gap:4}}>
          <div style={{width:7,height:7,borderRadius:'50%',background:zoneColor,
            boxShadow:`0 0 8px ${zoneColor}`}}/>
          <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:11,color:text3Col}}>
            {thread.active} active
          </span>
        </div>
        <span style={{fontSize:10,color:text3Col}}>·</span>
        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:11,color:text3Col}}>
          {thread.ago}
        </span>
      </div>
    </div>
  );
}

// ── Map Home Screen v3 ────────────────────────────────────────────────
function MapScreen3({ onThreadSelect, darkMode, setDarkMode }) {
  const [snapState, setSnapState] = React.useState('collapsed');
  const [layers, setLayers] = React.useState({food:true,nightlife:true,culture:true,outdoors:true,transit:true});

  const visibleThreads = D2C_THREADS.filter(t=>layers[t.zone]);

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%',
      background:darkMode?'var(--d2c-bg)':'#F5F5F8',position:'relative'}}>

      {/* Top Bar */}
      <div style={{position:'absolute',top:0,left:0,right:0,zIndex:1002,height:54,
        background:darkMode?'rgba(10,10,18,0.8)':'rgba(255,255,255,0.88)',
        backdropFilter:'blur(20px)',
        borderBottom:`1px solid ${darkMode?'rgba(42,42,64,0.5)':'rgba(0,0,0,0.06)'}`,
        display:'flex',alignItems:'center',padding:'0 14px',justifyContent:'space-between'}}>
        <button style={{background:'none',border:'none',
          color:darkMode?'var(--d2c-text-2)':'#666',
          fontSize:20,cursor:'pointer',padding:8,fontFamily:'inherit'}}>☰</button>
        <div style={{display:'flex',alignItems:'center',gap:6}}>
          <div style={{width:8,height:8,borderRadius:'50%',
            background:'linear-gradient(135deg,var(--d2c-violet),var(--d2c-pink))',
            boxShadow:'0 0 8px var(--d2c-violet-glow)'}}/>
          <span style={{fontSize:17,fontWeight:700,
            color:darkMode?'var(--d2c-text)':'#111',
            letterSpacing:'-0.03em',fontFamily:"'Space Grotesk',sans-serif"}}>d2c</span>
        </div>
        {/* Dark/Light toggle */}
        <button onClick={()=>setDarkMode(!darkMode)}
          style={{width:38,height:38,borderRadius:'50%',
            background:darkMode?'var(--d2c-surface-2)':'#fff',
            border:`1px solid ${darkMode?'var(--d2c-border)':'rgba(0,0,0,0.1)'}`,
            display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',
            fontSize:18,transition:'all 0.3s',
            boxShadow:darkMode?'none':'0 1px 4px rgba(0,0,0,0.08)',
            fontFamily:'inherit'}}>
          {darkMode ? '☀️' : '🌙'}
        </button>
      </div>

      {/* Leaflet Map */}
      <LeafletMap darkMode={darkMode} onThreadSelect={(t)=>{onThreadSelect(t);setSnapState('half');}} layers={layers}/>

      {/* Layer controls */}
      <LayerControl2 layers={layers} setLayers={setLayers} darkMode={darkMode}/>

      {/* Bottom sheet */}
      <Sheet3 threads={visibleThreads} onSelect={onThreadSelect}
        snapState={snapState} setSnapState={setSnapState} darkMode={darkMode}/>

      {/* FAB */}
      <div style={{position:'absolute',
        bottom:snapState==='collapsed'?140:snapState==='half'?'53%':'90%',
        right:14,transition:'bottom 0.4s cubic-bezier(0.32,0.72,0,1)',zIndex:1001}}>
        <button style={{width:56,height:56,borderRadius:'50%',
          background:'linear-gradient(135deg,var(--d2c-violet),var(--d2c-pink))',
          border:'none',color:'#fff',fontSize:26,fontWeight:300,cursor:'pointer',
          boxShadow:'0 0 30px var(--d2c-violet-glow), 0 8px 30px rgba(0,0,0,0.5)',
          display:'flex',alignItems:'center',justifyContent:'center',
          transition:'transform 0.2s',fontFamily:'inherit'}}
          onPointerDown={e=>e.currentTarget.style.transform='scale(0.92)'}
          onPointerUp={e=>e.currentTarget.style.transform='scale(1)'}
          onPointerLeave={e=>e.currentTarget.style.transform='scale(1)'}>
          +
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { MapScreen3, D2C_THREADS, ZONES_META, ZONE_COLORS });
