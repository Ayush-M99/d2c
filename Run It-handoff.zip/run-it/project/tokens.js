// ChatSpaces — Design Tokens
(function () {
  const dark = {
    '--cs-surface-deep': '#08080F',
    '--cs-surface-elevated': '#14141F',
    '--cs-surface-overlay': '#1F1F2E',
    '--cs-border-subtle': '#2A2A3D',
    '--cs-primary': '#6366F1',
    '--cs-primary-alpha': 'rgba(99,102,241,0.18)',
    '--cs-primary-glow': 'rgba(99,102,241,0.3)',
    '--cs-accent': '#22D3EE',
    '--cs-accent-alpha': 'rgba(34,211,238,0.15)',
    '--cs-premium': '#F59E0B',
    '--cs-premium-alpha': 'rgba(245,158,11,0.18)',
    '--cs-danger': '#EF4444',
    '--cs-success': '#10B981',
    '--cs-text-primary': '#F1F5F9',
    '--cs-text-secondary': '#94A3B8',
    '--cs-text-muted': '#64748B',
    '--cs-radius-sm': '6px',
    '--cs-radius-md': '12px',
    '--cs-radius-lg': '24px',
    '--cs-radius-full': '9999px',
    '--cs-shadow-soft': '0 4px 20px rgba(0,0,0,0.25)',
    '--cs-shadow-lift': '0 12px 40px rgba(0,0,0,0.4)',
    '--cs-glow-primary': '0 0 40px rgba(99,102,241,0.25)',
    '--cs-glow-premium': '0 0 60px rgba(245,158,11,0.30)',
  };

  const light = {
    '--cs-surface-deep': '#FAFBFC',
    '--cs-surface-elevated': '#FFFFFF',
    '--cs-surface-overlay': '#F1F5F9',
    '--cs-border-subtle': '#E2E8F0',
    '--cs-primary': '#4F46E5',
    '--cs-primary-alpha': 'rgba(79,70,229,0.1)',
    '--cs-primary-glow': 'rgba(79,70,229,0.2)',
    '--cs-accent': '#0891B2',
    '--cs-accent-alpha': 'rgba(8,145,178,0.1)',
    '--cs-premium': '#D97706',
    '--cs-premium-alpha': 'rgba(217,119,6,0.12)',
    '--cs-danger': '#DC2626',
    '--cs-success': '#059669',
    '--cs-text-primary': '#0F172A',
    '--cs-text-secondary': '#475569',
    '--cs-text-muted': '#94A3B8',
    '--cs-shadow-soft': '0 4px 20px rgba(0,0,0,0.06)',
    '--cs-shadow-lift': '0 12px 40px rgba(0,0,0,0.10)',
    '--cs-glow-primary': '0 0 30px rgba(79,70,229,0.15)',
    '--cs-glow-premium': '0 0 40px rgba(217,119,6,0.20)',
  };

  window.CS_TOKENS = { dark, light };

  window.applyCSTheme = function (theme) {
    const base = dark;
    const override = theme === 'light' ? light : {};
    const tokens = { ...base, ...override };
    const root = document.documentElement;
    Object.entries(tokens).forEach(([k, v]) => root.style.setProperty(k, v));
    document.documentElement.setAttribute('data-cs-theme', theme);
  };

  window.applyCSTheme('dark');
})();
