// ChatSpaces — Shared UI Primitives

// ── Geometric Avatar (deterministic from name string) ──────────────────────
function hashStr(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

function GeometricAvatar({ name = '', size = 40 }) {
  const h = hashStr(name || 'anon');
  const hues = [(h % 360), ((h * 137) % 360), ((h * 73) % 360)];
  const shapes = h % 3; // 0=triangles, 1=hexagon, 2=diamonds
  const s = size;
  const cx = s / 2, cy = s / 2, r = s * 0.38;
  const bg = `oklch(0.18 0.04 ${hues[0]})`;
  const c1 = `oklch(0.65 0.18 ${hues[0]})`;
  const c2 = `oklch(0.55 0.14 ${hues[1]})`;
  const c3 = `oklch(0.45 0.10 ${hues[2]})`;

  const pts = n => Array.from({ length: n }, (_, i) => {
    const a = (i / n) * Math.PI * 2 - Math.PI / 2;
    return [cx + Math.cos(a) * r, cy + Math.sin(a) * r];
  });

  let inner = null;
  if (shapes === 0) {
    const t = pts(3);
    inner = <polygon points={t.map(p => p.join(',')).join(' ')} fill={c1} opacity="0.9" />;
  } else if (shapes === 1) {
    const hex = pts(6);
    inner = <><polygon points={hex.map(p => p.join(',')).join(' ')} fill={c1} opacity="0.8" />
      <polygon points={pts(6).map((p, i) => [cx + (p[0]-cx)*0.55, cy + (p[1]-cy)*0.55].join(',')).join(' ')} fill={c2} opacity="0.7" /></>;
  } else {
    const d = pts(4);
    inner = <><polygon points={d.map(p => p.join(',')).join(' ')} fill={c1} opacity="0.85" />
      <polygon points={pts(4).map((p, i) => [cx + (p[0]-cx)*0.5, cy + (p[1]-cy)*0.5].join(',')).join(' ')} fill={c3} opacity="0.6" transform={`rotate(45 ${cx} ${cy})`} /></>;
  }

  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} style={{ borderRadius: '50%', flexShrink: 0 }}>
      <rect width={s} height={s} rx={s/2} fill={bg} />
      <circle cx={cx} cy={cy} r={r * 1.1} fill={c2} opacity="0.15" />
      {inner}
      <circle cx={cx} cy={cy} r={r * 0.18} fill={c3} opacity="0.9" />
    </svg>
  );
}

// ── Avatar Stack ──────────────────────────────────────────────────────────
function AvatarStack({ names = [], size = 28 }) {
  const shown = names.slice(0, 3);
  const extra = names.length - shown.length;
  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      {shown.map((n, i) => (
        <div key={i} style={{ marginLeft: i === 0 ? 0 : -size * 0.35, zIndex: shown.length - i,
          borderRadius: '50%', border: '2px solid var(--cs-surface-elevated)' }}>
          <GeometricAvatar name={n} size={size} />
        </div>
      ))}
      {extra > 0 && (
        <div style={{ marginLeft: -size * 0.35, width: size, height: size, borderRadius: '50%',
          background: 'var(--cs-surface-overlay)', border: '2px solid var(--cs-surface-elevated)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: size * 0.32, color: 'var(--cs-text-muted)', fontWeight: 600 }}>
          +{extra}
        </div>
      )}
    </div>
  );
}

// ── Tag Pill ──────────────────────────────────────────────────────────────
function TagPill({ label, color = 'primary', onRemove }) {
  const colors = {
    primary: { bg: 'var(--cs-primary-alpha)', text: 'var(--cs-primary)', border: 'var(--cs-primary)' },
    accent: { bg: 'var(--cs-accent-alpha)', text: 'var(--cs-accent)', border: 'var(--cs-accent)' },
    premium: { bg: 'var(--cs-premium-alpha)', text: 'var(--cs-premium)', border: 'var(--cs-premium)' },
    muted: { bg: 'transparent', text: 'var(--cs-text-muted)', border: 'var(--cs-border-subtle)' },
  };
  const c = colors[color] || colors.primary;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4,
      background: c.bg, color: c.text, border: `1px solid ${c.border}22`,
      borderRadius: 'var(--cs-radius-sm)', padding: '2px 8px',
      fontSize: 11, fontWeight: 500, letterSpacing: '0.02em', flexShrink: 0 }}>
      #{label}
      {onRemove && <span onClick={onRemove} style={{ cursor: 'pointer', opacity: 0.7, marginLeft: 2 }}>×</span>}
    </span>
  );
}

// ── Status Badge ──────────────────────────────────────────────────────────
function Badge({ type = 'active', label }) {
  const cfg = {
    active: { bg: 'var(--cs-success)', text: '#fff' },
    hot: { bg: 'var(--cs-danger)', text: '#fff' },
    new: { bg: 'var(--cs-accent)', text: '#0F172A' },
    premium: { bg: 'var(--cs-premium)', text: '#0F172A' },
  };
  const c = cfg[type] || cfg.active;
  return (
    <span style={{ background: c.bg, color: c.text, borderRadius: 'var(--cs-radius-sm)',
      padding: '2px 7px', fontSize: 10, fontWeight: 700, letterSpacing: '0.06em',
      textTransform: 'uppercase' }}>
      {label || type}
    </span>
  );
}

// ── Button ─────────────────────────────────────────────────────────────────
function CSButton({ variant = 'primary', size = 'md', children, onClick, disabled, loading, style: extraStyle }) {
  const [pressed, setPressed] = React.useState(false);
  const sizes = { sm: { h: 32, px: 14, fs: 13 }, md: { h: 40, px: 20, fs: 14 }, lg: { h: 48, px: 28, fs: 15 } };
  const sz = sizes[size] || sizes.md;
  const variants = {
    primary: { bg: 'var(--cs-primary)', color: '#fff', border: 'none', shadow: 'var(--cs-glow-primary)' },
    secondary: { bg: 'transparent', color: 'var(--cs-primary)', border: '1.5px solid var(--cs-primary)', shadow: 'none' },
    ghost: { bg: 'transparent', color: 'var(--cs-text-secondary)', border: '1.5px solid var(--cs-border-subtle)', shadow: 'none' },
    premium: { bg: 'linear-gradient(135deg, #F59E0B, #D97706)', color: '#fff', border: 'none', shadow: 'var(--cs-glow-premium)' },
    danger: { bg: 'var(--cs-danger)', color: '#fff', border: 'none', shadow: 'none' },
    text: { bg: 'transparent', color: 'var(--cs-primary)', border: 'none', shadow: 'none' },
  };
  const v = variants[variant] || variants.primary;
  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        height: sz.h, padding: `0 ${sz.px}px`, fontSize: sz.fs, fontWeight: 600,
        fontFamily: 'inherit', borderRadius: 'var(--cs-radius-md)',
        background: v.bg, color: v.color, border: v.border || 'none',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.4 : 1,
        boxShadow: pressed ? 'none' : v.shadow,
        transform: pressed ? 'scale(0.97)' : 'scale(1)',
        transition: 'transform 0.12s, box-shadow 0.12s, opacity 0.15s',
        letterSpacing: '0.01em', whiteSpace: 'nowrap',
        ...extraStyle,
      }}>
      {loading ? <span style={{ width: 16, height: 16, border: '2px solid currentColor',
        borderTopColor: 'transparent', borderRadius: '50%',
        animation: 'cs-spin 0.7s linear infinite', display: 'inline-block' }} /> : children}
    </button>
  );
}

// ── FAB ───────────────────────────────────────────────────────────────────
function FAB({ onClick, icon = '+' }) {
  const [hovered, setHovered] = React.useState(false);
  return (
    <button onClick={onClick}
      onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}
      style={{
        width: 56, height: 56, borderRadius: '50%',
        background: 'var(--cs-primary)', border: 'none',
        color: '#fff', fontSize: 26, fontWeight: 300,
        cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: hovered ? 'var(--cs-glow-primary), var(--cs-shadow-lift)' : 'var(--cs-shadow-lift)',
        transform: hovered ? 'scale(1.07)' : 'scale(1)',
        transition: 'transform 0.2s, box-shadow 0.2s',
        flexShrink: 0,
      }}>
      {icon}
    </button>
  );
}

// ── Thread Card ───────────────────────────────────────────────────────────
function ThreadCard({ thread, onClick, index = 0 }) {
  const [hovered, setHovered] = React.useState(false);
  const [pressed, setPressed] = React.useState(false);
  const intensityColor = thread.active > 20 ? 'var(--cs-danger)' :
    thread.active > 5 ? 'var(--cs-primary)' : 'var(--cs-accent)';

  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)} onMouseLeave={() => { setHovered(false); setPressed(false); }}
      onMouseDown={() => setPressed(true)} onMouseUp={() => setPressed(false)}
      style={{
        background: hovered ? 'var(--cs-surface-overlay)' : 'var(--cs-surface-elevated)',
        border: `1px solid ${hovered ? 'var(--cs-border-subtle)' : 'var(--cs-border-subtle)'}`,
        borderRadius: 'var(--cs-radius-md)', padding: '14px 16px',
        cursor: 'pointer', userSelect: 'none',
        transform: pressed ? 'scale(0.98)' : hovered ? 'translateY(-1px)' : 'none',
        boxShadow: hovered ? 'var(--cs-shadow-soft)' : 'none',
        transition: 'all 0.2s',
        animation: `cs-fadein 0.3s ease both`,
        animationDelay: `${index * 55}ms`,
      }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--cs-text-primary)',
            marginBottom: 6, lineHeight: 1.3 }}>{thread.title}</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 8 }}>
            {thread.tags.map(t => <TagPill key={t} label={t} />)}
          </div>
          <div style={{ fontSize: 13, color: 'var(--cs-text-secondary)', fontStyle: 'italic',
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            "{thread.lastMessage}"
          </div>
        </div>
        <AvatarStack names={thread.participants} size={26} />
      </div>
      <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
        <div style={{ width: 6, height: 6, borderRadius: '50%', background: intensityColor,
          boxShadow: `0 0 6px ${intensityColor}` }} />
        <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: 'var(--cs-text-muted)' }}>
          {thread.active} active · {thread.ago}
        </span>
        {thread.active > 20 && <Badge type="hot" label="hot" />}
      </div>
    </div>
  );
}

// ── Toast ──────────────────────────────────────────────────────────────────
function Toast({ message, type = 'info', visible }) {
  const colors = {
    info: { bg: 'var(--cs-surface-overlay)', border: 'var(--cs-border-subtle)', icon: 'ℹ' },
    success: { bg: '#10B98120', border: 'var(--cs-success)', icon: '✓' },
    error: { bg: '#EF444420', border: 'var(--cs-danger)', icon: '✕' },
    warn: { bg: '#F59E0B20', border: 'var(--cs-premium)', icon: '!' },
  };
  const c = colors[type] || colors.info;
  return (
    <div style={{
      position: 'absolute', top: 70, left: '50%',
      transform: `translateX(-50%) translateY(${visible ? 0 : -80}px)`,
      opacity: visible ? 1 : 0, transition: 'all 0.3s cubic-bezier(0.34,1.56,0.64,1)',
      background: c.bg, border: `1px solid ${c.border}`,
      borderRadius: 'var(--cs-radius-md)', padding: '10px 16px',
      display: 'flex', alignItems: 'center', gap: 8,
      color: 'var(--cs-text-primary)', fontSize: 13, fontWeight: 500,
      backdropFilter: 'blur(12px)', zIndex: 999, whiteSpace: 'nowrap',
      boxShadow: 'var(--cs-shadow-lift)',
    }}>
      <span>{c.icon}</span> {message}
    </div>
  );
}

// ── Typing Indicator ──────────────────────────────────────────────────────
function TypingIndicator({ name }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0' }}>
      <div style={{ display: 'flex', gap: 3, alignItems: 'center',
        background: 'var(--cs-surface-elevated)',
        padding: '8px 12px', borderRadius: '12px 12px 12px 4px' }}>
        {[0, 1, 2].map(i => (
          <div key={i} style={{
            width: 6, height: 6, borderRadius: '50%',
            background: 'var(--cs-text-muted)',
            animation: 'cs-bounce 1.2s ease infinite',
            animationDelay: `${i * 0.18}s`,
          }} />
        ))}
      </div>
      <span style={{ fontSize: 11, color: 'var(--cs-text-muted)', fontStyle: 'italic' }}>{name} is typing</span>
    </div>
  );
}

// ── Skeleton Shimmer ──────────────────────────────────────────────────────
function Skeleton({ width = '100%', height = 16, radius = 8 }) {
  return (
    <div style={{ width, height, borderRadius: radius,
      background: 'linear-gradient(90deg, var(--cs-surface-elevated) 25%, var(--cs-surface-overlay) 50%, var(--cs-surface-elevated) 75%)',
      backgroundSize: '200% 100%', animation: 'cs-shimmer 1.4s infinite' }} />
  );
}

// ── Global Styles ──────────────────────────────────────────────────────────
function GlobalStyles() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

      *, *::before, *::after { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }

      @keyframes cs-spin { to { transform: rotate(360deg); } }
      @keyframes cs-bounce {
        0%, 80%, 100% { transform: translateY(0); opacity: 0.4; }
        40% { transform: translateY(-5px); opacity: 1; }
      }
      @keyframes cs-shimmer { from { background-position: 200% 0; } to { background-position: -200% 0; } }
      @keyframes cs-fadein { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
      @keyframes cs-pulse-ring {
        0% { transform: scale(1); opacity: 0.6; }
        100% { transform: scale(2.4); opacity: 0; }
      }
      @keyframes cs-you-breathe {
        0%, 100% { transform: scale(1); opacity: 0.5; }
        50% { transform: scale(1.5); opacity: 0.2; }
      }
      @keyframes cs-bubble-in {
        from { opacity: 0; transform: translateY(10px) scale(0.96); }
        to { opacity: 1; transform: translateY(0) scale(1); }
      }
      @keyframes cs-slide-in-right {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
      @keyframes cs-slide-out-left {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(-30px); opacity: 0; }
      }
      @keyframes cs-sheet-up {
        from { transform: translateY(40px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
      }
      @keyframes cs-confetti-burst {
        0% { transform: translate(0,0) scale(1); opacity: 1; }
        100% { transform: translate(var(--tx), var(--ty)) scale(0); opacity: 0; }
      }
    `}</style>
  );
}

Object.assign(window, { GeometricAvatar, AvatarStack, TagPill, Badge, CSButton, FAB, ThreadCard, Toast, TypingIndicator, Skeleton, GlobalStyles, hashStr });
