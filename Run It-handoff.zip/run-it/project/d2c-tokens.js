// d2c — Design Tokens v2: vibrant, alive, addictive
(function () {
  const dark = {
    '--d2c-bg': '#0A0A12',
    '--d2c-surface': '#111119',
    '--d2c-surface-2': '#1A1A26',
    '--d2c-surface-3': '#222233',
    '--d2c-border': '#2A2A40',
    '--d2c-border-glow': 'rgba(120,90,255,0.25)',

    // Vibrant palette
    '--d2c-violet': '#8B5CF6',
    '--d2c-violet-glow': 'rgba(139,92,246,0.35)',
    '--d2c-cyan': '#06D6A0',
    '--d2c-cyan-glow': 'rgba(6,214,160,0.30)',
    '--d2c-orange': '#FF6B35',
    '--d2c-orange-glow': 'rgba(255,107,53,0.30)',
    '--d2c-pink': '#FF3CAC',
    '--d2c-pink-glow': 'rgba(255,60,172,0.25)',
    '--d2c-gold': '#FFD166',
    '--d2c-gold-glow': 'rgba(255,209,102,0.30)',
    '--d2c-blue': '#4CC9F0',
    '--d2c-blue-glow': 'rgba(76,201,240,0.25)',
    '--d2c-red': '#EF4444',
    '--d2c-green': '#10B981',

    // Zone colors
    '--d2c-zone-food': 'rgba(255,107,53,0.18)',
    '--d2c-zone-food-border': 'rgba(255,107,53,0.45)',
    '--d2c-zone-nightlife': 'rgba(255,60,172,0.16)',
    '--d2c-zone-nightlife-border': 'rgba(255,60,172,0.40)',
    '--d2c-zone-culture': 'rgba(139,92,246,0.16)',
    '--d2c-zone-culture-border': 'rgba(139,92,246,0.40)',
    '--d2c-zone-outdoors': 'rgba(6,214,160,0.14)',
    '--d2c-zone-outdoors-border': 'rgba(6,214,160,0.40)',
    '--d2c-zone-transit': 'rgba(76,201,240,0.14)',
    '--d2c-zone-transit-border': 'rgba(76,201,240,0.35)',

    // Text
    '--d2c-text': '#F0F0F8',
    '--d2c-text-2': '#A0A0BE',
    '--d2c-text-3': '#606080',
    '--d2c-text-inv': '#0A0A12',

    // Radii
    '--d2c-r-sm': '8px',
    '--d2c-r-md': '14px',
    '--d2c-r-lg': '22px',
    '--d2c-r-xl': '28px',
    '--d2c-r-full': '999px',

    // Map specifics
    '--d2c-map-land': '#0C0C18',
    '--d2c-map-block': '#0F0F1E',
    '--d2c-map-block-alt': '#12122A',
    '--d2c-map-road': '#1C1C35',
    '--d2c-map-road-minor': '#14142A',
    '--d2c-map-water': '#081428',
    '--d2c-map-park': '#0A1A10',
    '--d2c-map-building': '#181830',
    '--d2c-map-label': '#3A3A60',
  };

  window.D2C = dark;
  window.applyD2C = function () {
    const root = document.documentElement;
    Object.entries(dark).forEach(([k, v]) => root.style.setProperty(k, v));
  };
  window.applyD2C();
})();
