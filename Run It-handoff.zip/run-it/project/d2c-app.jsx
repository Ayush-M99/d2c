// d2c — App Shell v2

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "dark",
  "animatePins": true,
  "vibrancy": "high"
}/*EDITMODE-END*/;

function D2CApp() {
  const [screen, setScreen] = React.useState('map');
  const [selectedThread, setSelectedThread] = React.useState(null);
  const [showTweaks, setShowTweaks] = React.useState(false);
  const tweaks = useTweaks(TWEAK_DEFAULTS);

  // Tweaks panel protocol
  React.useEffect(() => {
    const handler = (e) => {
      if (e.data?.type === '__activate_edit_mode') setShowTweaks(true);
      if (e.data?.type === '__deactivate_edit_mode') setShowTweaks(false);
    };
    window.addEventListener('message', handler);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', handler);
  }, []);

  const navigateTo = (s, t) => {
    if (t) setSelectedThread(t);
    setScreen(s);
  };

  return (
    <div style={{width:'100%',height:'100%',position:'relative',
      fontFamily:"'DM Sans',sans-serif",overflow:'hidden',
      background:'var(--d2c-bg)',color:'var(--d2c-text)'}}>

      <D2CStyles/>

      {screen === 'map' && (
        <MapScreen2 onThreadSelect={t => navigateTo('chat', t)} />
      )}
      {screen === 'chat' && (
        <ChatScreen2 thread={selectedThread} onBack={() => setScreen('map')} />
      )}

      {showTweaks && (
        <TweaksPanel onClose={() => {
          setShowTweaks(false);
          window.parent.postMessage({ type: '__edit_mode_dismissed' }, '*');
        }}>
          <TweakSection title="Navigate">
            <TweakButton label="→ Map Home" onClick={() => setScreen('map')} />
            <TweakButton label="→ Chat View" onClick={() => {
              setSelectedThread(D2C_THREADS[0]);
              setScreen('chat');
            }} />
          </TweakSection>
          <TweakSection title="Settings">
            <TweakRadio label="Vibrancy"
              value={tweaks.vibrancy}
              options={[{label:'High',value:'high'},{label:'Medium',value:'medium'},{label:'Subtle',value:'subtle'}]}
              onChange={v => tweaks.set('vibrancy', v)} />
            <TweakToggle label="Animate pins" value={tweaks.animatePins}
              onChange={v => tweaks.set('animatePins', v)} />
          </TweakSection>
        </TweaksPanel>
      )}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<D2CApp />);
