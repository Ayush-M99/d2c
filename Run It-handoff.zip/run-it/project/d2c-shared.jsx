// d2c — Shared Components v2

function hashStr(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

const VIBE_COLORS = ['#8B5CF6','#06D6A0','#FF6B35','#FF3CAC','#FFD166','#4CC9F0','#EF4444','#F97316'];

function vibeColor(name) { return VIBE_COLORS[hashStr(name || '') % VIBE_COLORS.length]; }

// ── Geometric Avatar v2 — more vibrant ────────────────────────────────
function Avatar({ name = '', size = 40 }) {
  const h = hashStr(name);
  const hue1 = h % 360, hue2 = (h * 137) % 360;
  const bg = `oklch(0.22 0.06 ${hue1})`;
  const c1 = `oklch(0.70 0.22 ${hue1})`;
  const c2 = `oklch(0.60 0.18 ${hue2})`;
  const s = size, cx = s/2, cy = s/2, r = s*0.34;
  const shape = h % 4;

  const ring = (n, scale) => Array.from({length:n},(_,i)=>{
    const a = (i/n)*Math.PI*2 - Math.PI/2;
    return [cx+Math.cos(a)*r*scale, cy+Math.sin(a)*r*scale];
  });

  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} style={{borderRadius:'50%',flexShrink:0}}>
      <defs>
        <radialGradient id={`ag${h}`} cx="40%" cy="35%">
          <stop offset="0%" stopColor={c1} stopOpacity="0.9"/>
          <stop offset="100%" stopColor={bg}/>
        </radialGradient>
      </defs>
      <circle cx={cx} cy={cy} r={s/2} fill={`url(#ag${h})`}/>
      {shape===0 && <polygon points={ring(3,1).map(p=>p.join(',')).join(' ')} fill={c1} opacity="0.85"/>}
      {shape===1 && <polygon points={ring(6,1).map(p=>p.join(',')).join(' ')} fill={c1} opacity="0.7"/>}
      {shape===2 && <polygon points={ring(4,1).map(p=>p.join(',')).join(' ')} fill={c2} opacity="0.8"/>}
      {shape===3 && <><circle cx={cx} cy={cy} r={r*0.9} fill="none" stroke={c1} strokeWidth={2} opacity="0.7"/>
        <circle cx={cx} cy={cy} r={r*0.5} fill={c2} opacity="0.6"/></>}
      <circle cx={cx} cy={cy} r={r*0.2} fill="#fff" opacity="0.8"/>
    </svg>
  );
}

function AvatarStack({ names=[], size=28 }) {
  const shown = names.slice(0,3);
  const extra = names.length - shown.length;
  return (
    <div style={{display:'flex',alignItems:'center'}}>
      {shown.map((n,i)=>(
        <div key={i} style={{marginLeft:i?-size*0.3:0,zIndex:shown.length-i,
          borderRadius:'50%',border:'2px solid var(--d2c-surface)'}}>
          <Avatar name={n} size={size}/>
        </div>
      ))}
      {extra>0 && <div style={{marginLeft:-size*0.3,width:size,height:size,borderRadius:'50%',
        background:'var(--d2c-surface-3)',border:'2px solid var(--d2c-surface)',
        display:'flex',alignItems:'center',justifyContent:'center',
        fontSize:size*0.32,color:'var(--d2c-text-2)',fontWeight:700}}>+{extra}</div>}
    </div>
  );
}

// ── Tag Pill — vibrant ────────────────────────────────────────────────
function Pill({ label, color, glow, small }) {
  const c = color || 'var(--d2c-violet)';
  return (
    <span style={{display:'inline-flex',alignItems:'center',gap:3,
      background:`${c}18`,color:c,border:`1px solid ${c}44`,
      borderRadius:'var(--d2c-r-full)',padding:small?'1px 7px':'3px 10px',
      fontSize:small?10:11,fontWeight:600,letterSpacing:'0.02em',
      boxShadow:glow?`0 0 12px ${c}22`:'none',
      whiteSpace:'nowrap',flexShrink:0}}>
      {label}
    </span>
  );
}

// ── Button ────────────────────────────────────────────────────────────
function Btn({ children, variant='primary', onClick, disabled, style:extra }) {
  const [p, setP] = React.useState(false);
  const v = {
    primary: {bg:'var(--d2c-violet)',c:'#fff',shadow:'0 0 24px var(--d2c-violet-glow)'},
    cyan: {bg:'var(--d2c-cyan)',c:'#0A0A12',shadow:'0 0 24px var(--d2c-cyan-glow)'},
    orange: {bg:'var(--d2c-orange)',c:'#fff',shadow:'0 0 24px var(--d2c-orange-glow)'},
    ghost: {bg:'transparent',c:'var(--d2c-text-2)',border:'1.5px solid var(--d2c-border)',shadow:'none'},
    gold: {bg:'linear-gradient(135deg,#FFD166,#FF6B35)',c:'#0A0A12',shadow:'0 0 30px rgba(255,209,102,0.3)'},
  }[variant] || {};
  return (
    <button onClick={onClick} disabled={disabled}
      onPointerDown={()=>setP(true)} onPointerUp={()=>setP(false)} onPointerLeave={()=>setP(false)}
      style={{display:'inline-flex',alignItems:'center',justifyContent:'center',gap:8,
        height:44,padding:'0 22px',fontSize:14,fontWeight:700,fontFamily:'inherit',
        borderRadius:'var(--d2c-r-full)',background:v.bg,color:v.c,
        border:v.border||'none',cursor:disabled?'not-allowed':'pointer',
        opacity:disabled?0.4:1,boxShadow:p?'none':v.shadow,
        transform:p?'scale(0.96)':'scale(1)',transition:'all 0.15s',
        letterSpacing:'0.01em',...extra}}>
      {children}
    </button>
  );
}

// ── Thread Card v2 — more alive ───────────────────────────────────────
function ThreadCard2({ thread, onClick, index=0 }) {
  const [hov, setHov] = React.useState(false);
  const zoneColor = {
    food:'var(--d2c-orange)', nightlife:'var(--d2c-pink)', culture:'var(--d2c-violet)',
    outdoors:'var(--d2c-cyan)', transit:'var(--d2c-blue)', default:'var(--d2c-violet)',
  }[thread.zone||'default'];
  const isHot = thread.active > 20;

  return (
    <div onClick={onClick}
      onPointerEnter={()=>setHov(true)} onPointerLeave={()=>setHov(false)}
      style={{
        background: hov ? 'var(--d2c-surface-2)' : 'var(--d2c-surface)',
        border:`1px solid ${hov ? zoneColor+'55' : 'var(--d2c-border)'}`,
        borderRadius:'var(--d2c-r-md)',padding:'14px 16px',cursor:'pointer',
        position:'relative',overflow:'hidden',
        transform:hov?'translateY(-2px) scale(1.005)':'none',
        boxShadow:hov?`0 8px 32px ${zoneColor}15, 0 0 0 1px ${zoneColor}22`:'none',
        transition:'all 0.22s cubic-bezier(0.34,1.2,0.64,1)',
        animation:`d2c-fadein 0.35s ease both`,animationDelay:`${index*60}ms`,
      }}>
      {/* Zone accent line */}
      <div style={{position:'absolute',top:0,left:0,width:3,height:'100%',
        background:`linear-gradient(180deg,${zoneColor},transparent)`,borderRadius:'0 2px 2px 0'}}/>
      
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',gap:12}}>
        <div style={{flex:1,minWidth:0,paddingLeft:6}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
            <span style={{fontSize:17}}>{thread.emoji}</span>
            <span style={{fontSize:15,fontWeight:700,color:'var(--d2c-text)',lineHeight:1.3,
              fontFamily:"'Space Grotesk',sans-serif"}}>{thread.title}</span>
          </div>
          <div style={{display:'flex',flexWrap:'wrap',gap:4,marginBottom:8}}>
            {thread.tags.map(t=><Pill key={t} label={`#${t}`} color={zoneColor} small/>)}
            {isHot && <Pill label="🔥 hot" color="var(--d2c-red)" glow small/>}
          </div>
          <div style={{fontSize:13,color:'var(--d2c-text-2)',fontStyle:'italic',
            overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
            "{thread.lastMessage}"
          </div>
        </div>
        <AvatarStack names={thread.participants} size={26}/>
      </div>
      <div style={{marginTop:10,display:'flex',alignItems:'center',gap:8,paddingLeft:6}}>
        <div style={{display:'flex',alignItems:'center',gap:4}}>
          <div style={{width:7,height:7,borderRadius:'50%',background:zoneColor,
            boxShadow:`0 0 8px ${zoneColor}`}}/>
          <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:11,color:'var(--d2c-text-3)'}}>
            {thread.active} active
          </span>
        </div>
        <span style={{fontSize:10,color:'var(--d2c-text-3)'}}>·</span>
        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:11,color:'var(--d2c-text-3)'}}>
          {thread.ago}
        </span>
      </div>
    </div>
  );
}

// ── Typing Dots ───────────────────────────────────────────────────────
function TypingDots({ name }) {
  return (
    <div style={{display:'flex',alignItems:'center',gap:8,padding:'4px 0'}}>
      <div style={{display:'flex',gap:3,background:'var(--d2c-surface)',
        padding:'8px 14px',borderRadius:'14px 14px 14px 4px',border:'1px solid var(--d2c-border)'}}>
        {[0,1,2].map(i=><div key={i} style={{width:6,height:6,borderRadius:'50%',
          background:'var(--d2c-violet)',animation:'d2c-bounce 1.2s ease infinite',
          animationDelay:`${i*0.18}s`}}/>)}
      </div>
      <span style={{fontSize:11,color:'var(--d2c-text-3)',fontStyle:'italic'}}>{name} typing</span>
    </div>
  );
}

// ── Toast ──────────────────────────────────────────────────────────────
function Toast2({ message, type='info', visible }) {
  const c = {info:'var(--d2c-violet)',success:'var(--d2c-cyan)',error:'var(--d2c-red)',warn:'var(--d2c-orange)'}[type];
  return (
    <div style={{position:'absolute',top:12,left:'50%',
      transform:`translateX(-50%) translateY(${visible?0:-60}px)`,
      opacity:visible?1:0,transition:'all 0.35s cubic-bezier(0.34,1.56,0.64,1)',
      background:'var(--d2c-surface-2)',border:`1px solid ${c}`,
      borderRadius:'var(--d2c-r-full)',padding:'8px 18px',
      display:'flex',alignItems:'center',gap:8,
      color:'var(--d2c-text)',fontSize:13,fontWeight:600,
      backdropFilter:'blur(16px)',zIndex:999,whiteSpace:'nowrap',
      boxShadow:`0 8px 32px rgba(0,0,0,0.4), 0 0 20px ${c}22`}}>
      {message}
    </div>
  );
}

// ── Global Styles v2 ──────────────────────────────────────────────────
function D2CStyles() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=DM+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&family=JetBrains+Mono:wght@400;500&display=swap');
      *,*::before,*::after{box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
      @keyframes d2c-fadein{from{opacity:0;transform:translateY(14px);}to{opacity:1;transform:translateY(0);}}
      @keyframes d2c-bounce{0%,80%,100%{transform:translateY(0);opacity:0.4;}40%{transform:translateY(-5px);opacity:1;}}
      @keyframes d2c-pulse{0%{transform:scale(1);opacity:0.7;}100%{transform:scale(2.8);opacity:0;}}
      @keyframes d2c-breathe{0%,100%{transform:scale(1);opacity:0.4;}50%{transform:scale(1.6);opacity:0.15;}}
      @keyframes d2c-glow-rotate{0%{filter:hue-rotate(0deg);}100%{filter:hue-rotate(30deg);}}
      @keyframes d2c-slide-in{from{transform:translateX(100%);opacity:0;}to{transform:translateX(0);opacity:1;}}
      @keyframes d2c-sheet-up{from{transform:translateY(60px);opacity:0;}to{transform:translateY(0);opacity:1;}}
      @keyframes d2c-shimmer{from{background-position:200% 0;}to{background-position:-200% 0;}}
      @keyframes d2c-float{0%,100%{transform:translateY(0);}50%{transform:translateY(-4px);}}
      @keyframes d2c-zone-pulse{0%,100%{opacity:0.12;}50%{opacity:0.22;}}
      @keyframes d2c-spin{to{transform:rotate(360deg);}}
    `}</style>
  );
}

Object.assign(window, { Avatar, AvatarStack, Pill, Btn, ThreadCard2, TypingDots, Toast2, D2CStyles, hashStr, vibeColor, VIBE_COLORS });
