// d2c — Rich Interactive Map with Zones, Layers, Pan/Zoom

const D2C_THREADS = [
  { id:1, title:'Blue Tokai — anyone here?', tags:['cafe','coffee'], active:14, ago:'now', participants:['BraveOtter','QuietWolf','NeonFox','StormCrow','GlassHawk'], lastMessage:'got the corner table, filter coffee is crazy today', emoji:'☕', zone:'food', x:0.30, y:0.48 },
  { id:2, title:'FC vs MI watch party', tags:['sports','live'], active:32, ago:'1m', participants:['WildLynx','SaltRidge','IronDawn'], lastMessage:'pub on MG road, big screen, no cover', emoji:'⚽', zone:'nightlife', x:0.52, y:0.64 },
  { id:3, title:'Monsoon walk from Cubbon', tags:['outdoors','walk'], active:8, ago:'3m', participants:['MistPine','DuskBird'], lastMessage:'drizzling but honestly perfect for it', emoji:'🌧', zone:'outdoors', x:0.12, y:0.66 },
  { id:4, title:'Late night ramen — Shivaji', tags:['food','latenight'], active:11, ago:'2m', participants:['RedCoral','SandPeak','NightOwl'], lastMessage:'spot near the bus stand still open', emoji:'🍜', zone:'food', x:0.36, y:0.52 },
  { id:5, title:'Power cut Indiranagar?', tags:['local','help'], active:22, ago:'4m', participants:['CalmReed','StoneLeaf','AshWren','TideCliff'], lastMessage:'yep whole sector 5 is out again', emoji:'💡', zone:'transit', x:0.90, y:0.40 },
  { id:6, title:'Open mic at Fandom tonight', tags:['music','culture'], active:19, ago:'5m', participants:['VoidPulse','SilkRain','NightBloom'], lastMessage:'starts at 9, get there early for seats', emoji:'🎤', zone:'culture', x:0.16, y:0.20 },
  { id:7, title:'Pottery class — Commercial St', tags:['art','workshop'], active:5, ago:'8m', participants:['ClayHand','GoldSpark'], lastMessage:'₹500 for 2 hours, really therapeutic', emoji:'🏺', zone:'culture', x:0.12, y:0.28 },
];

const ZONES = [
  { id:'food', label:'Food & Drink', color:'#FF6B35', emoji:'🍽', paths:[
    {cx:0.28,cy:0.42,rx:0.14,ry:0.12},
    {cx:0.34,cy:0.30,rx:0.08,ry:0.06},
  ]},
  { id:'nightlife', label:'Nightlife', color:'#FF3CAC', emoji:'🌃', paths:[
    {cx:0.68,cy:0.38,rx:0.13,ry:0.10},
  ]},
  { id:'culture', label:'Arts & Culture', color:'#8B5CF6', emoji:'🎨', paths:[
    {cx:0.52,cy:0.24,rx:0.15,ry:0.10},
    {cx:0.40,cy:0.78,rx:0.10,ry:0.07},
  ]},
  { id:'outdoors', label:'Parks & Outdoors', color:'#06D6A0', emoji:'🌿', paths:[
    {cx:0.50,cy:0.62,rx:0.12,ry:0.10},
  ]},
  { id:'transit', label:'Transit & Local', color:'#4CC9F0', emoji:'🚌', paths:[
    {cx:0.78,cy:0.68,rx:0.10,ry:0.08},
  ]},
];

// ── Canvas Map Renderer (uses d2c-maprender.jsx) ─────────────────────
function useCanvasMap(canvasRef, width, height, offset, scale, layers, time) {
  React.useEffect(() => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx || !width || !height) return;
    if (window.drawCityMap) {
      window.drawCityMap(ctx, width, height, offset, scale, layers);
      return;
    }
    // Fallback — should not happen
    ctx.fillStyle = '#0A0A16';
    ctx.fillRect(0, 0, width, height);
  }, [width, height, offset, scale, layers, time]);
}

// ── Hotspot Pin v2 ────────────────────────────────────────────────────
function Pin2({ thread, onClick, scale, offset, mapW, mapH }) {
  const zoneColor = {food:'#FF6B35',nightlife:'#FF3CAC',culture:'#8B5CF6',
    outdoors:'#06D6A0',transit:'#4CC9F0'}[thread.zone] || '#8B5CF6';
  const [pressed, setPressed] = React.useState(false);
  const px = thread.x * mapW * scale + offset.x;
  const py = thread.y * mapH * scale + offset.y;
  const isHot = thread.active > 20;
  const pinSize = isHot ? 18 : 14;

  return (
    <div onClick={onClick}
      onPointerDown={()=>setPressed(true)} onPointerUp={()=>setPressed(false)}
      style={{position:'absolute',left:px,top:py,
        transform:`translate(-50%,-50%) scale(${pressed?0.88:1})`,
        transition:'transform 0.12s',cursor:'pointer',
        display:'flex',flexDirection:'column',alignItems:'center',zIndex:12}}>
      {/* Pulse rings */}
      {[0,1,2].map(i=>(
        <div key={i} style={{position:'absolute',width:pinSize*2,height:pinSize*2,
          borderRadius:'50%',border:`1.5px solid ${zoneColor}`,
          animation:'d2c-pulse 2.5s ease-out infinite',animationDelay:`${i*0.45}s`}}/>
      ))}
      {/* Glow */}
      <div style={{position:'absolute',width:pinSize*3,height:pinSize*3,borderRadius:'50%',
        background:`radial-gradient(circle,${zoneColor}20 0%,transparent 70%)`,
        animation:'d2c-float 3s ease-in-out infinite',animationDelay:`${thread.id*0.3}s`}}/>
      {/* Core */}
      <div style={{width:pinSize,height:pinSize,borderRadius:'50%',
        background:`radial-gradient(circle at 35% 35%,${zoneColor},${zoneColor}88)`,
        boxShadow:`0 0 16px ${zoneColor}88, 0 0 4px ${zoneColor}`,
        position:'relative',zIndex:2,
        border:'2px solid rgba(255,255,255,0.15)'}}/>
      {/* Label */}
      <div style={{marginTop:5,background:'rgba(10,10,18,0.92)',backdropFilter:'blur(12px)',
        border:`1px solid ${zoneColor}44`,borderRadius:'var(--d2c-r-full)',
        padding:'2px 9px',fontSize:11,color:'var(--d2c-text)',fontWeight:700,
        whiteSpace:'nowrap',fontFamily:"'Space Grotesk',sans-serif",
        boxShadow:`0 4px 16px rgba(0,0,0,0.5), 0 0 8px ${zoneColor}15`,
        display:'flex',alignItems:'center',gap:4}}>
        <span>{thread.emoji}</span>
        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,
          color:zoneColor,fontWeight:600}}>{thread.active}</span>
      </div>
    </div>
  );
}

// ── You Pin ───────────────────────────────────────────────────────────
function YouPin2({ scale, offset, mapW, mapH }) {
  const px = 0.52*mapW*scale + offset.x;
  const py = 0.48*mapH*scale + offset.y;
  return (
    <div style={{position:'absolute',left:px,top:py,transform:'translate(-50%,-50%)',zIndex:12}}>
      <div style={{position:'absolute',width:40,height:40,borderRadius:'50%',
        background:'var(--d2c-violet)',opacity:0.2,animation:'d2c-breathe 2s ease-in-out infinite',
        left:-12,top:-12}}/>
      <div style={{width:18,height:18,borderRadius:'50%',
        background:'linear-gradient(135deg,var(--d2c-violet),var(--d2c-pink))',
        boxShadow:'0 0 20px var(--d2c-violet-glow), 0 0 6px var(--d2c-pink-glow)',
        display:'flex',alignItems:'center',justifyContent:'center',
        border:'2.5px solid rgba(255,255,255,0.3)',position:'relative',zIndex:2}}>
        <div style={{width:5,height:5,borderRadius:'50%',background:'#fff'}}/>
      </div>
    </div>
  );
}

// ── Layer Control ─────────────────────────────────────────────────────
function LayerControl({ layers, setLayers }) {
  return (
    <div style={{position:'absolute',top:62,left:10,zIndex:30,
      display:'flex',flexDirection:'column',gap:4,
      }}>
      {ZONES.map(z => {
        const active = layers[z.id];
        return (
          <button key={z.id}
            onClick={() => setLayers(l => ({...l, [z.id]: !l[z.id]}))}
            style={{display:'flex',alignItems:'center',gap:6,
              background: active ? `${z.color}18` : 'rgba(10,10,18,0.85)',
              backdropFilter:'blur(12px)',
              border:`1px solid ${active ? z.color+'55' : 'var(--d2c-border)'}`,
              borderRadius:'var(--d2c-r-full)',padding:'5px 10px',
              cursor:'pointer',transition:'all 0.2s',
              boxShadow: active ? `0 0 12px ${z.color}22` : 'none',
              fontFamily:'inherit'}}>
            <span style={{fontSize:12}}>{z.emoji}</span>
            <span style={{fontSize:10,fontWeight:600,
              color: active ? z.color : 'var(--d2c-text-3)',
              fontFamily:"'Space Grotesk',sans-serif",letterSpacing:'0.02em'}}>
              {z.label}
            </span>
            <div style={{width:8,height:8,borderRadius:'50%',
              background: active ? z.color : 'var(--d2c-border)',
              boxShadow: active ? `0 0 6px ${z.color}` : 'none',
              transition:'all 0.2s'}}/>
          </button>
        );
      })}
    </div>
  );
}

// ── Bottom Sheet v2 ───────────────────────────────────────────────────
function Sheet2({ threads, onSelect, snapState, setSnapState }) {
  const [tab, setTab] = React.useState('nearby');
  const [search, setSearch] = React.useState('');

  const filtered = threads.filter(t => {
    if (tab === 'hot') return t.active > 10;
    if (tab === 'foryou') return ['food','culture','outdoors'].includes(t.zone);
    if (tab === 'search' && search) return t.title.toLowerCase().includes(search.toLowerCase()) || t.tags.some(tag=>tag.includes(search.toLowerCase()));
    return true;
  });

  const SNAPS = { collapsed: 118, half: '50%', full: '88%' };
  const h = SNAPS[snapState];

  return (
    <div style={{position:'absolute',bottom:0,left:0,right:0,height:h,
      background:'rgba(10,10,18,0.95)',backdropFilter:'blur(24px)',
      borderRadius:'22px 22px 0 0',
      border:'1px solid var(--d2c-border)',borderBottom:'none',
      transition:'height 0.4s cubic-bezier(0.32,0.72,0,1)',
      display:'flex',flexDirection:'column',overflow:'hidden',zIndex:25,
      boxShadow:'0 -12px 60px rgba(0,0,0,0.6), 0 -2px 20px rgba(139,92,246,0.06)',
      }}>

      {/* Handle */}
      <div style={{padding:'10px 0 6px',cursor:'pointer',flexShrink:0,userSelect:'none'}}
        onClick={()=>setSnapState(s=>s==='collapsed'?'half':s==='half'?'full':'collapsed')}>
        <div style={{width:36,height:4,borderRadius:2,
          background:'linear-gradient(90deg,var(--d2c-violet),var(--d2c-pink))',
          margin:'0 auto',opacity:0.5}}/>
      </div>

      {/* Header */}
      <div style={{padding:'0 16px 10px',flexShrink:0}}>
        <div style={{fontSize:12,color:'var(--d2c-text-3)',marginBottom:8,
          fontFamily:"'JetBrains Mono',monospace",letterSpacing:'0.04em'}}>
          around you · <span style={{color:'var(--d2c-cyan)',fontWeight:600}}>
            {threads.reduce((a,t)=>a+t.active,0)} chatting
          </span>
        </div>
        <div style={{display:'flex',gap:5,overflow:'auto',scrollbarWidth:'none'}}>
          {[{id:'nearby',l:'🗺 nearby'},{id:'hot',l:'🔥 hot'},{id:'foryou',l:'✨ for you'},{id:'search',l:'🔍'}].map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)}
              style={{padding:'6px 14px',borderRadius:'var(--d2c-r-full)',
                background:tab===t.id?'var(--d2c-violet)':'var(--d2c-surface-2)',
                color:tab===t.id?'#fff':'var(--d2c-text-2)',
                border:tab===t.id?'none':`1px solid var(--d2c-border)`,
                fontSize:12,fontWeight:600,cursor:'pointer',transition:'all 0.18s',
                fontFamily:"'Space Grotesk',sans-serif",whiteSpace:'nowrap',
                boxShadow:tab===t.id?'0 0 16px var(--d2c-violet-glow)':'none'}}>
              {t.l}
            </button>
          ))}
        </div>
        {tab==='search' && <input autoFocus placeholder="search threads, places..." value={search}
          onChange={e=>setSearch(e.target.value)}
          style={{marginTop:8,width:'100%',background:'var(--d2c-surface-2)',
            border:'1px solid var(--d2c-border)',borderRadius:'var(--d2c-r-md)',
            padding:'9px 14px',color:'var(--d2c-text)',fontSize:13,
            fontFamily:"'DM Sans',sans-serif",outline:'none'}}/>}
      </div>

      {/* Thread list */}
      <div style={{flex:1,overflowY:'auto',padding:'0 14px 80px',scrollbarWidth:'none'}}>
        <div style={{display:'flex',flexDirection:'column',gap:10}}>
          {filtered.map((t,i)=><ThreadCard2 key={t.id} thread={t} index={i} onClick={()=>onSelect(t)}/>)}
          {filtered.length===0 && <div style={{textAlign:'center',padding:'32px 0',color:'var(--d2c-text-3)',fontSize:13}}>no threads here yet</div>}
        </div>
      </div>
    </div>
  );
}

// ── Map Home Screen v2 ────────────────────────────────────────────────
function MapScreen2({ onThreadSelect }) {
  const containerRef = React.useRef(null);
  const canvasRef = React.useRef(null);
  const [size, setSize] = React.useState({w:375,h:600});
  const [offset, setOffset] = React.useState({x:0,y:0});
  const [scale, setScale] = React.useState(1);
  const [dragging, setDragging] = React.useState(false);
  const dragStart = React.useRef(null);
  const offsetStart = React.useRef(null);
  const [snapState, setSnapState] = React.useState('collapsed');
  const [layers, setLayers] = React.useState({food:true,nightlife:true,culture:true,outdoors:true,transit:true});
  const [time, setTime] = React.useState(0);

  // Animate
  React.useEffect(()=>{
    let frame;
    const tick=()=>{setTime(t=>t+1);frame=requestAnimationFrame(tick);};
    frame=requestAnimationFrame(tick);
    return ()=>cancelAnimationFrame(frame);
  },[]);

  React.useEffect(()=>{
    const measure=()=>{
      if(containerRef.current){
        setSize({w:containerRef.current.offsetWidth,h:containerRef.current.offsetHeight});
      }
    };
    measure(); window.addEventListener('resize',measure);
    return ()=>window.removeEventListener('resize',measure);
  },[]);

  // Draw map
  useCanvasMap(canvasRef, size.w, size.h, offset, scale, layers, time);

  // Pan
  const onPointerDown=e=>{
    if(e.target.closest('button')||e.target.closest('[data-layer]')||e.target.closest('[data-sheet]')||e.target.closest('[data-pin]'))return;
    setDragging(true);
    dragStart.current={x:e.clientX,y:e.clientY};
    offsetStart.current={...offset};
  };
  const onPointerMove=e=>{
    if(!dragging||!dragStart.current)return;
    const dx=e.clientX-dragStart.current.x;
    const dy=e.clientY-dragStart.current.y;
    setOffset({x:offsetStart.current.x+dx,y:offsetStart.current.y+dy});
  };
  const onPointerUp=()=>setDragging(false);

  // Zoom
  const onWheel=e=>{
    e.preventDefault();
    const delta=e.deltaY>0?0.92:1.08;
    setScale(s=>Math.max(0.5,Math.min(3,s*delta)));
  };

  // Filter threads by active layers
  const visibleThreads = D2C_THREADS.filter(t=>layers[t.zone]);

  return (
    <div ref={containerRef}
      style={{display:'flex',flexDirection:'column',height:'100%',
        background:'var(--d2c-bg)',position:'relative',cursor:dragging?'grabbing':'grab',
        touchAction:'none',userSelect:'none'}}
      onPointerDown={onPointerDown} onPointerMove={onPointerMove}
      onPointerUp={onPointerUp} onPointerLeave={onPointerUp}
      onWheel={onWheel}>

      {/* Top bar */}
      <div style={{position:'absolute',top:0,left:0,right:0,zIndex:30,height:54,
        background:'rgba(10,10,18,0.7)',backdropFilter:'blur(20px)',
        borderBottom:'1px solid rgba(42,42,64,0.5)',
        display:'flex',alignItems:'center',padding:'0 14px',justifyContent:'space-between'}}>
        <button style={{background:'none',border:'none',color:'var(--d2c-text-2)',
          fontSize:20,cursor:'pointer',padding:8,fontFamily:'inherit'}}>☰</button>
        <div style={{display:'flex',alignItems:'center',gap:6}}>
          <div style={{width:8,height:8,borderRadius:'50%',
            background:'linear-gradient(135deg,var(--d2c-violet),var(--d2c-pink))',
            boxShadow:'0 0 8px var(--d2c-violet-glow)'}}/>
          <span style={{fontSize:17,fontWeight:700,color:'var(--d2c-text)',
            letterSpacing:'-0.03em',fontFamily:"'Space Grotesk',sans-serif"}}>d2c</span>
        </div>
        <div style={{width:36,height:36,borderRadius:'50%',
          background:'var(--d2c-surface-2)',border:'1px solid var(--d2c-border)',
          display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer'}}>
          <Avatar name="me" size={28}/>
        </div>
      </div>

      {/* Canvas map */}
      <canvas ref={canvasRef} width={size.w} height={size.h}
        style={{position:'absolute',inset:0,width:'100%',height:'100%'}}/>

      {/* Layer controls */}
      <div data-layer>
        <LayerControl layers={layers} setLayers={setLayers}/>
      </div>

      {/* Pins */}
      {visibleThreads.map(t=>(
        <div key={t.id} data-pin onClick={()=>{onThreadSelect(t);setSnapState('half');}}>
          <Pin2 thread={t} onClick={()=>{onThreadSelect(t);setSnapState('half');}}
            scale={scale} offset={offset} mapW={size.w} mapH={size.h}/>
        </div>
      ))}
      <YouPin2 scale={scale} offset={offset} mapW={size.w} mapH={size.h}/>

      {/* Zoom controls */}
      <div style={{position:'absolute',bottom:140,right:14,zIndex:28,
        display:'flex',flexDirection:'column',gap:6}}>
        {[{l:'+',d:1.2},{l:'−',d:0.8}].map(z=>(
          <button key={z.l} onClick={()=>setScale(s=>Math.max(0.5,Math.min(3,s*z.d)))}
            style={{width:38,height:38,borderRadius:'50%',
              background:'rgba(10,10,18,0.88)',backdropFilter:'blur(12px)',
              border:'1px solid var(--d2c-border)',color:'var(--d2c-text)',
              fontSize:18,fontWeight:300,cursor:'pointer',
              display:'flex',alignItems:'center',justifyContent:'center',
              fontFamily:'inherit'}}>
            {z.l}
          </button>
        ))}
        <button onClick={()=>{setScale(1);setOffset({x:0,y:0});}}
          style={{width:38,height:38,borderRadius:'50%',
            background:'rgba(10,10,18,0.88)',backdropFilter:'blur(12px)',
            border:'1px solid var(--d2c-border)',color:'var(--d2c-text-3)',
            fontSize:14,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',
            fontFamily:"'JetBrains Mono',monospace",fontWeight:500}}>
          ⌖
        </button>
      </div>

      {/* Bottom sheet */}
      <div data-sheet>
        <Sheet2 threads={visibleThreads} onSelect={onThreadSelect}
          snapState={snapState} setSnapState={setSnapState}/>
      </div>

      {/* FAB */}
      <div style={{position:'absolute',bottom:snapState==='collapsed'?140:snapState==='half'?'53%':'90%',
        right:14,transition:'bottom 0.4s cubic-bezier(0.32,0.72,0,1)',zIndex:28}}>
        <button style={{width:56,height:56,borderRadius:'50%',
          background:'linear-gradient(135deg,var(--d2c-violet),var(--d2c-pink))',
          border:'none',color:'#fff',fontSize:26,fontWeight:300,cursor:'pointer',
          boxShadow:'0 0 30px var(--d2c-violet-glow), 0 8px 30px rgba(0,0,0,0.5)',
          display:'flex',alignItems:'center',justifyContent:'center',
          transition:'transform 0.2s',fontFamily:'inherit'}}
          onPointerDown={e=>e.currentTarget.style.transform='scale(0.92)'}
          onPointerUp={e=>e.currentTarget.style.transform='scale(1)'}
          onPointerLeave={e=>e.currentTarget.style.transform='scale(1)'}>
          +
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { MapScreen2, D2C_THREADS, ZONES });
