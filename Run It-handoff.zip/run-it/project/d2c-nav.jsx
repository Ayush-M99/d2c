// d2c — Bottom Nav Bar + Create Thread Sheet

// ── SVG Icons (Lucide-style, 1.5px stroke) ───────────────────────────
const NavIcons = {
  explore: (color) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10"/>
      <polygon points="16.24,7.76 14.12,14.12 7.76,16.24 9.88,9.88" fill={color} fillOpacity="0.15"/>
    </svg>
  ),
  threads: (color) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      <line x1="8" y1="8" x2="16" y2="8" opacity="0.5"/>
      <line x1="8" y1="12" x2="13" y2="12" opacity="0.5"/>
    </svg>
  ),
  dm: (color) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
      <polyline points="22,6 12,13 2,6"/>
    </svg>
  ),
  profile: (color) => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
      <circle cx="12" cy="7" r="4"/>
    </svg>
  ),
};

// ── Bottom Nav Bar ────────────────────────────────────────────────────
function BottomNav({ activeTab, onTabChange, onCreateThread, darkMode, hasNotification }) {
  const bg = darkMode ? 'rgba(10,10,18,0.96)' : 'rgba(255,255,255,0.97)';
  const border = darkMode ? 'rgba(42,42,64,0.5)' : 'rgba(0,0,0,0.06)';
  const inactiveColor = darkMode ? '#606080' : '#AAAABD';
  const activeColor = '#8B5CF6';

  const tabs = [
    { id: 'explore', label: 'explore', icon: NavIcons.explore },
    { id: 'threads', label: 'threads', icon: NavIcons.threads },
    { id: 'create', label: '', icon: null }, // placeholder for FAB
    { id: 'dm', label: 'dm', icon: NavIcons.dm, badge: hasNotification },
    { id: 'profile', label: 'profile', icon: NavIcons.profile },
  ];

  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 1003,
      height: 64,
      background: bg, backdropFilter: 'blur(24px)',
      borderTop: `1px solid ${border}`,
      display: 'flex', alignItems: 'center', justifyContent: 'space-around',
      padding: '0 8px',
    }}>
      {tabs.map(tab => {
        if (tab.id === 'create') {
          // Center FAB
          return (
            <button key="create" onClick={onCreateThread}
              style={{
                width: 48, height: 48, borderRadius: '50%',
                background: 'linear-gradient(135deg, #8B5CF6, #FF3CAC)',
                border: 'none', color: '#fff', fontSize: 24, fontWeight: 300,
                cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
                boxShadow: '0 0 24px rgba(139,92,246,0.35), 0 4px 16px rgba(0,0,0,0.3)',
                marginTop: -14, position: 'relative', zIndex: 2,
                transition: 'transform 0.15s', fontFamily: 'inherit',
              }}
              onPointerDown={e => e.currentTarget.style.transform = 'scale(0.90) rotate(45deg)'}
              onPointerUp={e => e.currentTarget.style.transform = 'scale(1) rotate(0deg)'}
              onPointerLeave={e => e.currentTarget.style.transform = 'scale(1) rotate(0deg)'}>
              +
            </button>
          );
        }

        const isActive = activeTab === tab.id;
        const color = isActive ? activeColor : inactiveColor;

        return (
          <button key={tab.id} onClick={() => onTabChange(tab.id)}
            style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
              background: 'none', border: 'none', cursor: 'pointer',
              padding: '6px 12px', position: 'relative',
              transition: 'all 0.15s', fontFamily: 'inherit',
            }}>
            {/* Active indicator dot */}
            {isActive && (
              <div style={{
                position: 'absolute', top: -1, width: 20, height: 3, borderRadius: 2,
                background: 'linear-gradient(90deg, #8B5CF6, #FF3CAC)',
                boxShadow: '0 0 8px rgba(139,92,246,0.4)',
              }} />
            )}
            <div style={{ transform: isActive ? 'scale(1.1)' : 'scale(1)', transition: 'transform 0.15s' }}>
              {tab.icon(color)}
            </div>
            <span style={{
              fontSize: 9, fontWeight: isActive ? 700 : 500, color,
              fontFamily: "'Space Grotesk',sans-serif", letterSpacing: '0.04em',
              transition: 'color 0.15s',
            }}>{tab.label}</span>
            {/* Notification badge */}
            {tab.badge && (
              <div style={{
                position: 'absolute', top: 2, right: 6,
                width: 8, height: 8, borderRadius: '50%',
                background: '#EF4444', border: `2px solid ${darkMode ? '#0A0A12' : '#fff'}`,
                boxShadow: '0 0 6px rgba(239,68,68,0.5)',
              }} />
            )}
          </button>
        );
      })}
    </div>
  );
}

// ── Create Thread Bottom Sheet ────────────────────────────────────────
function CreateThreadSheet({ visible, onClose, onSubmit, darkMode }) {
  const [title, setTitle] = React.useState('');
  const [threadType, setThreadType] = React.useState('chat');
  const [tags, setTags] = React.useState([]);
  const [tagInput, setTagInput] = React.useState('');
  const [pollOptions, setPollOptions] = React.useState(['', '']);

  const bg = darkMode ? 'rgba(10,10,20,0.98)' : 'rgba(255,255,255,0.99)';
  const surface = darkMode ? 'var(--d2c-surface-2)' : '#F5F5F8';
  const border = darkMode ? 'var(--d2c-border)' : 'rgba(0,0,0,0.08)';
  const text = darkMode ? 'var(--d2c-text)' : '#111';
  const text2 = darkMode ? 'var(--d2c-text-2)' : '#555';
  const text3 = darkMode ? 'var(--d2c-text-3)' : '#999';

  const types = [
    { id: 'chat', emoji: '💬', label: 'text' },
    { id: 'poll', emoji: '📊', label: 'poll' },
    { id: 'qa', emoji: '❓', label: 'q&a' },
    { id: 'countdown', emoji: '⏱', label: 'timer' },
  ];

  const addTag = () => {
    if (tagInput.trim() && tags.length < 5 && !tags.includes(tagInput.trim().toLowerCase())) {
      setTags([...tags, tagInput.trim().toLowerCase()]);
      setTagInput('');
    }
  };

  const handleSubmit = () => {
    if (!title.trim()) return;
    onSubmit({ title: title.trim(), type: threadType, tags, pollOptions: threadType === 'poll' ? pollOptions.filter(o => o.trim()) : [] });
    setTitle(''); setTags([]); setTagInput(''); setThreadType('chat'); setPollOptions(['', '']);
    onClose();
  };

  if (!visible) return null;

  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 2000,
      display: 'flex', flexDirection: 'column', justifyContent: 'flex-end',
    }}>
      {/* Backdrop */}
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.5)',
        backdropFilter: 'blur(6px)',
      }} />

      {/* Sheet */}
      <div style={{
        position: 'relative', zIndex: 1,
        background: bg, backdropFilter: 'blur(24px)',
        borderRadius: '22px 22px 0 0',
        border: `1px solid ${border}`, borderBottom: 'none',
        padding: '0 0 20px',
        maxHeight: '78%', display: 'flex', flexDirection: 'column',
        boxShadow: darkMode ? '0 -16px 60px rgba(0,0,0,0.7)' : '0 -8px 40px rgba(0,0,0,0.1)',
      }}>
        {/* Handle */}
        <div style={{ padding: '10px 0 6px', cursor: 'pointer', flexShrink: 0 }} onClick={onClose}>
          <div style={{
            width: 36, height: 4, borderRadius: 2,
            background: darkMode ? 'linear-gradient(90deg,var(--d2c-violet),var(--d2c-pink))' : 'rgba(0,0,0,0.15)',
            margin: '0 auto', opacity: darkMode ? 0.5 : 1,
          }} />
        </div>

        <div style={{ padding: '0 20px', overflowY: 'auto', flex: 1, scrollbarWidth: 'none' }}>
          {/* Title */}
          <div style={{
            fontSize: 16, fontWeight: 700, color: text,
            fontFamily: "'Space Grotesk',sans-serif", marginBottom: 16,
          }}>new thread</div>

          {/* Title input */}
          <div style={{ marginBottom: 16 }}>
            <textarea
              value={title}
              onChange={e => { if (e.target.value.length <= 120) setTitle(e.target.value); }}
              placeholder="what's happening nearby?"
              rows={2}
              autoFocus
              style={{
                width: '100%', background: surface, border: `1px solid ${border}`,
                borderRadius: 'var(--d2c-r-md)', padding: '12px 14px',
                color: text, fontSize: 18, fontWeight: 600,
                fontFamily: "'Space Grotesk',sans-serif",
                outline: 'none', resize: 'none', lineHeight: 1.4,
              }}
            />
            <div style={{
              textAlign: 'right', fontSize: 10, color: title.length > 100 ? 'var(--d2c-red)' : text3,
              fontFamily: "'JetBrains Mono',monospace", marginTop: 4,
            }}>{title.length}/120</div>
          </div>

          {/* Thread type */}
          <div style={{ marginBottom: 16 }}>
            <div style={{
              fontSize: 11, fontWeight: 600, color: text2, marginBottom: 8,
              fontFamily: "'Space Grotesk',sans-serif", letterSpacing: '0.04em', textTransform: 'uppercase',
            }}>what kind?</div>
            <div style={{ display: 'flex', gap: 8 }}>
              {types.map(t => {
                const active = threadType === t.id;
                return (
                  <button key={t.id} onClick={() => setThreadType(t.id)}
                    style={{
                      flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
                      padding: '10px 8px', borderRadius: 'var(--d2c-r-md)',
                      background: active ? 'var(--d2c-violet)' : surface,
                      border: active ? 'none' : `1px solid ${border}`,
                      color: active ? '#fff' : text2, cursor: 'pointer',
                      boxShadow: active ? '0 0 20px var(--d2c-violet-glow)' : 'none',
                      transition: 'all 0.18s', fontFamily: 'inherit',
                    }}>
                    <span style={{ fontSize: 20 }}>{t.emoji}</span>
                    <span style={{
                      fontSize: 10, fontWeight: 600,
                      fontFamily: "'Space Grotesk',sans-serif",
                    }}>{t.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Tags */}
          <div style={{ marginBottom: 16 }}>
            <div style={{
              fontSize: 11, fontWeight: 600, color: text2, marginBottom: 8,
              fontFamily: "'Space Grotesk',sans-serif", letterSpacing: '0.04em', textTransform: 'uppercase',
            }}>tags</div>
            <div style={{
              display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 8,
            }}>
              {tags.map(t => (
                <span key={t} onClick={() => setTags(tags.filter(x => x !== t))}
                  style={{
                    display: 'inline-flex', alignItems: 'center', gap: 4,
                    background: 'var(--d2c-violet)18', color: 'var(--d2c-violet)',
                    border: '1px solid rgba(139,92,246,0.3)',
                    borderRadius: 'var(--d2c-r-full)', padding: '3px 10px',
                    fontSize: 11, fontWeight: 600, cursor: 'pointer',
                    fontFamily: "'JetBrains Mono',monospace",
                  }}>
                  #{t} <span style={{ opacity: 0.6 }}>×</span>
                </span>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                value={tagInput}
                onChange={e => setTagInput(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addTag(); } }}
                placeholder="add tag..."
                style={{
                  flex: 1, background: surface, border: `1px solid ${border}`,
                  borderRadius: 'var(--d2c-r-md)', padding: '8px 12px',
                  color: text, fontSize: 13, fontFamily: "'DM Sans',sans-serif",
                  outline: 'none',
                }}
              />
              <button onClick={addTag}
                style={{
                  padding: '8px 14px', borderRadius: 'var(--d2c-r-md)',
                  background: surface, border: `1px solid ${border}`,
                  color: text2, fontSize: 12, fontWeight: 600, cursor: 'pointer',
                  fontFamily: "'Space Grotesk',sans-serif",
                }}>+</button>
            </div>
          </div>

          {/* Poll options (conditional) */}
          {threadType === 'poll' && (
            <div style={{ marginBottom: 16 }}>
              <div style={{
                fontSize: 11, fontWeight: 600, color: text2, marginBottom: 8,
                fontFamily: "'Space Grotesk',sans-serif", letterSpacing: '0.04em', textTransform: 'uppercase',
              }}>options</div>
              {pollOptions.map((opt, i) => (
                <input key={i}
                  value={opt}
                  onChange={e => {
                    const next = [...pollOptions];
                    next[i] = e.target.value;
                    setPollOptions(next);
                  }}
                  placeholder={`option ${i + 1}`}
                  style={{
                    width: '100%', background: surface, border: `1px solid ${border}`,
                    borderRadius: 'var(--d2c-r-md)', padding: '8px 12px',
                    color: text, fontSize: 13, fontFamily: "'DM Sans',sans-serif",
                    outline: 'none', marginBottom: 6,
                  }}
                />
              ))}
              {pollOptions.length < 6 && (
                <button onClick={() => setPollOptions([...pollOptions, ''])}
                  style={{
                    background: 'none', border: 'none', color: 'var(--d2c-violet)',
                    fontSize: 12, fontWeight: 600, cursor: 'pointer', padding: '4px 0',
                    fontFamily: "'Space Grotesk',sans-serif",
                  }}>+ add option</button>
              )}
            </div>
          )}
        </div>

        {/* Submit button */}
        <div style={{ padding: '0 20px', flexShrink: 0 }}>
          <button onClick={handleSubmit}
            disabled={!title.trim()}
            style={{
              width: '100%', height: 48, borderRadius: 'var(--d2c-r-full)',
              background: title.trim()
                ? 'linear-gradient(135deg, #8B5CF6, #FF3CAC)'
                : surface,
              border: title.trim() ? 'none' : `1px solid ${border}`,
              color: title.trim() ? '#fff' : text3,
              fontSize: 15, fontWeight: 700, cursor: title.trim() ? 'pointer' : 'not-allowed',
              fontFamily: "'Space Grotesk',sans-serif",
              boxShadow: title.trim() ? '0 0 30px var(--d2c-violet-glow)' : 'none',
              transition: 'all 0.2s', letterSpacing: '-0.01em',
            }}>
            create thread
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Placeholder screens ───────────────────────────────────────────────
function PlaceholderScreen({ title, emoji, darkMode }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      height: '100%', gap: 12, paddingBottom: 64,
      background: darkMode ? 'var(--d2c-bg)' : '#F5F5F8',
    }}>
      <span style={{ fontSize: 48, opacity: 0.4 }}>{emoji}</span>
      <span style={{
        fontSize: 16, fontWeight: 600, color: darkMode ? 'var(--d2c-text-3)' : '#999',
        fontFamily: "'Space Grotesk',sans-serif",
      }}>{title}</span>
      <span style={{
        fontSize: 12, color: darkMode ? 'var(--d2c-text-3)' : '#bbb',
        fontFamily: "'JetBrains Mono',monospace",
      }}>coming soon</span>
    </div>
  );
}

Object.assign(window, { BottomNav, CreateThreadSheet, PlaceholderScreen, NavIcons });
