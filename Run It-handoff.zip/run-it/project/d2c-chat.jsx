// d2c — Chat Screen v2: vibrant, alive

const CHAT_MESSAGES = [
  { id:1, from:'BraveOtter', text:'yo who\'s at blue tokai rn', time:'2:41p', mine:false },
  { id:2, from:'NeonFox', text:'been here since 10! corner booth near the espresso bar', time:'2:42p', mine:false },
  { id:3, from:'me', text:'omw, 5 mins. save me a spot?', time:'2:43p', mine:true },
  { id:4, from:'BraveOtter', text:'we\'re 4 already but big table free near the window', time:'2:43p', mine:false },
  { id:5, type:'system', text:'QuietWolf joined' },
  { id:6, from:'QuietWolf', text:'which floor is everyone on?', time:'2:44p', mine:false },
  { id:7, from:'NeonFox', text:'ground floor, you\'ll see us', time:'2:44p', mine:false },
  { id:8, type:'image', from:'BraveOtter', time:'2:45p', mine:false, caption:'the vibe rn ☕' },
];

const INCOMING = [
  { from:'QuietWolf', text:'ok I can see you guys 👋', delay:3500 },
  { from:'BraveOtter', text:'the filter coffee today is absolutely insane', delay:8000 },
  { from:'NeonFox', text:'monsoon rain + coffee = perfect combo honestly', delay:13000 },
  { from:'StormCrow', text:'anyone want to split a cab to koramangala after?', delay:19000 },
];

// ── View-Once Image v2 ───────────────────────────────────────────────
function ViewOnce2({ caption, onViewed }) {
  const [state, setState] = React.useState('idle');
  const [count, setCount] = React.useState(8);

  const handleTap = () => {
    if (state === 'idle') {
      setState('revealing');
      setTimeout(() => {
        setState('counting');
        let c = 8;
        const iv = setInterval(() => {
          c--;
          setCount(c);
          if (c <= 0) { clearInterval(iv); setState('dissolving'); setTimeout(() => setState('viewed'), 900); }
        }, 1000);
      }, 800);
    } else if (state === 'counting') {
      setState('dissolving');
      setTimeout(() => setState('viewed'), 800);
    }
  };

  if (state === 'viewed') {
    return (
      <div style={{width:180,height:100,borderRadius:'var(--d2c-r-md)',
        background:'var(--d2c-surface-2)',border:'1px solid var(--d2c-border)',
        display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:4}}>
        <span style={{fontSize:16,opacity:0.3}}>👁</span>
        <span style={{fontSize:10,color:'var(--d2c-text-3)',fontFamily:"'JetBrains Mono',monospace"}}>viewed</span>
      </div>
    );
  }

  const revealed = state === 'revealing' || state === 'counting' || state === 'dissolving';
  const circ = 2 * Math.PI * 42;

  return (
    <div onClick={handleTap} style={{width:200,height:180,position:'relative',
      cursor:state==='idle'?'pointer':'default',borderRadius:'var(--d2c-r-md)',overflow:'hidden'}}>
      {/* Photo simulation */}
      <div style={{position:'absolute',inset:0,
        background:'linear-gradient(135deg,#1a1028 0%,#0d1b2a 40%,#16213e 70%,#2a1040 100%)'}}>
        <div style={{position:'absolute',bottom:0,left:0,right:0,height:'35%',
          background:'rgba(139,90,43,0.2)'}}/>
        <div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center'}}>
          <span style={{fontSize:36,opacity:0.5}}>☕</span>
        </div>
      </div>

      {/* Origami fold panels */}
      {[
        {top:0,left:0,w:'50%',h:'50%',origin:'100% 100%'},
        {top:0,right:0,w:'50%',h:'50%',origin:'0% 100%'},
        {bottom:0,left:0,w:'50%',h:'50%',origin:'100% 0%'},
        {bottom:0,right:0,w:'50%',h:'50%',origin:'0% 0%'},
      ].map((p,i) => (
        <div key={i} style={{
          position:'absolute',top:p.top,left:p.left,right:p.right,bottom:p.bottom,
          width:p.w,height:p.h,
          background:'var(--d2c-surface)',
          transformOrigin:p.origin,
          transform:revealed?'perspective(300px) rotateY(90deg)':'none',
          transition:revealed?`transform 0.4s cubic-bezier(0.34,1.2,0.64,1) ${i*0.15}s`:'none',
          zIndex:5,
        }}/>
      ))}

      {/* Blur overlay */}
      <div style={{position:'absolute',inset:0,backdropFilter:revealed?'blur(0px)':'blur(18px)',
        transition:'backdrop-filter 0.5s',zIndex:3}}/>

      {/* Dissolve */}
      {state==='dissolving' && <div style={{position:'absolute',inset:0,zIndex:10,
        background:'var(--d2c-bg)',animation:'d2c-fadein 0.8s ease forwards'}}/>}

      {/* Idle state */}
      {state==='idle' && (
        <div style={{position:'absolute',inset:0,zIndex:10,
          display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:8,
          background:'rgba(10,10,18,0.3)'}}>
          <div style={{width:44,height:44,borderRadius:'50%',
            background:'rgba(139,92,246,0.2)',border:'1.5px solid rgba(139,92,246,0.4)',
            display:'flex',alignItems:'center',justifyContent:'center',
            backdropFilter:'blur(4px)'}}>
            <span style={{fontSize:20}}>👁</span>
          </div>
          <span style={{fontSize:11,fontWeight:600,color:'var(--d2c-text-2)',
            fontFamily:"'Space Grotesk',sans-serif"}}>view once</span>
        </div>
      )}

      {/* Countdown ring */}
      {state==='counting' && (
        <div style={{position:'absolute',top:8,right:8,zIndex:15}}>
          <svg width={32} height={32} style={{transform:'rotate(-90deg)'}}>
            <circle cx={16} cy={16} r={13} fill="rgba(10,10,18,0.7)" stroke="rgba(255,255,255,0.1)" strokeWidth={2.5}/>
            <circle cx={16} cy={16} r={13} fill="none"
              stroke="var(--d2c-orange)" strokeWidth={2.5}
              strokeDasharray={circ} strokeDashoffset={circ*(1-count/8)}
              strokeLinecap="round" style={{transition:'stroke-dashoffset 0.9s linear'}}/>
          </svg>
          <span style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',
            fontSize:11,fontWeight:700,color:'#fff',fontFamily:"'JetBrains Mono',monospace"}}>{count}</span>
        </div>
      )}
    </div>
  );
}

// ── Chat Bubble ───────────────────────────────────────────────────────
function Bubble2({ msg, showName, isLast }) {
  const [showTime, setShowTime] = React.useState(false);
  const color = vibeColor(msg.from);

  if (msg.type === 'system') {
    return (
      <div style={{textAlign:'center',padding:'8px 0',}}>
        <span style={{fontSize:11,color:'var(--d2c-text-3)',
          background:'var(--d2c-surface-2)',padding:'3px 14px',
          borderRadius:'var(--d2c-r-full)',border:'1px solid var(--d2c-border)',
          fontFamily:"'DM Sans',sans-serif"}}>
          {msg.text}
        </span>
      </div>
    );
  }

  const isImage = msg.type === 'image';

  return (
    <div style={{display:'flex',flexDirection:'column',
      alignItems:msg.mine?'flex-end':'flex-start',
      marginBottom:isLast?6:2,
      }}>
      {showName && !msg.mine && (
        <span style={{fontSize:11,fontWeight:700,marginBottom:3,marginLeft:4,
          color,fontFamily:"'Space Grotesk',sans-serif"}}>{msg.from}</span>
      )}
      <div
        onPointerEnter={()=>setShowTime(true)} onPointerLeave={()=>setShowTime(false)}
        style={{
          maxWidth:isImage?'auto':'78%',
          background:isImage?'none':msg.mine
            ? 'linear-gradient(135deg,rgba(139,92,246,0.22),rgba(255,60,172,0.12))'
            : 'var(--d2c-surface)',
          border:isImage?'none':msg.mine
            ? '1px solid rgba(139,92,246,0.3)' : '1px solid var(--d2c-border)',
          borderRadius:msg.mine?'18px 18px 6px 18px':'18px 18px 18px 6px',
          padding:isImage?0:'10px 14px',
          fontSize:14,color:'var(--d2c-text)',lineHeight:1.55,
          fontFamily:"'DM Sans',sans-serif",
          boxShadow:msg.mine?'0 2px 12px rgba(139,92,246,0.08)':'none',
        }}>
        {isImage ? <ViewOnce2 caption={msg.caption}/> : msg.text}
      </div>
      {(showTime || isLast) && msg.time && (
        <span style={{fontSize:10,color:'var(--d2c-text-3)',marginTop:2,
          fontFamily:"'JetBrains Mono',monospace",
          marginLeft:msg.mine?0:4,marginRight:msg.mine?4:0,
          opacity:showTime?1:0.5,transition:'opacity 0.15s'}}>
          {msg.time}
        </span>
      )}
    </div>
  );
}

// ── Chat Screen v2 ────────────────────────────────────────────────────
function ChatScreen2({ thread, onBack }) {
  const [messages, setMessages] = React.useState(CHAT_MESSAGES);
  const [input, setInput] = React.useState('');
  const [isTyping, setIsTyping] = React.useState(false);
  const [typingName, setTypingName] = React.useState('');
  const [toast, setToast] = React.useState({visible:false,msg:'',type:'info'});
  const listRef = React.useRef(null);

  const scrollBottom = () => { if(listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight; };
  React.useEffect(()=>{scrollBottom();},[messages]);

  React.useEffect(()=>{
    const timers = INCOMING.map((inc,i) => {
      const t1 = setTimeout(()=>{setTypingName(inc.from);setIsTyping(true);}, inc.delay-1500);
      const t2 = setTimeout(()=>{
        setIsTyping(false);
        setMessages(p=>[...p,{id:Date.now()+i,from:inc.from,text:inc.text,
          time:new Date().toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit',hour12:true}).replace(' ','').toLowerCase(),
          mine:false}]);
      }, inc.delay);
      return [t1,t2];
    });
    return ()=>timers.flat().forEach(clearTimeout);
  },[]);

  const send = () => {
    if(!input.trim())return;
    setMessages(p=>[...p,{id:Date.now(),from:'me',text:input.trim(),
      time:new Date().toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit',hour12:true}).replace(' ','').toLowerCase(),
      mine:true}]);
    setInput('');
  };

  const t = thread || D2C_THREADS[0];
  const zoneColor = {food:'#FF6B35',nightlife:'#FF3CAC',culture:'#8B5CF6',
    outdoors:'#06D6A0',transit:'#4CC9F0'}[t.zone] || '#8B5CF6';

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%',
      background:'var(--d2c-bg)',position:'relative',
      }}>

      <Toast2 visible={toast.visible} message={toast.msg} type={toast.type}/>

      {/* Header */}
      <div style={{height:62,padding:'0 12px',flexShrink:0,
        background:'rgba(10,10,18,0.9)',backdropFilter:'blur(20px)',
        borderBottom:`1px solid ${zoneColor}22`,
        display:'flex',alignItems:'center',gap:10}}>
        <button onClick={onBack} style={{background:'none',border:'none',
          color:'var(--d2c-violet)',fontSize:22,cursor:'pointer',padding:'4px 8px',
          fontFamily:'inherit',display:'flex',alignItems:'center'}}>←</button>
        <div style={{flex:1,minWidth:0}}>
          <div style={{display:'flex',alignItems:'center',gap:6}}>
            <span style={{fontSize:16}}>{t.emoji}</span>
            <span style={{fontSize:15,fontWeight:700,color:'var(--d2c-text)',
              fontFamily:"'Space Grotesk',sans-serif",
              overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{t.title}</span>
          </div>
          <div style={{display:'flex',alignItems:'center',gap:6,marginTop:2}}>
            <div style={{width:6,height:6,borderRadius:'50%',background:zoneColor,
              boxShadow:`0 0 6px ${zoneColor}`}}/>
            <span style={{fontSize:11,color:'var(--d2c-text-3)',
              fontFamily:"'JetBrains Mono',monospace"}}>{t.active} active</span>
            <Pill label={t.zone} color={zoneColor} small/>
          </div>
        </div>
        <button style={{background:'none',border:'none',color:'var(--d2c-text-3)',
          fontSize:20,cursor:'pointer',padding:6,fontFamily:'inherit'}}>⋯</button>
      </div>

      {/* Zone accent gradient */}
      <div style={{height:2,flexShrink:0,
        background:`linear-gradient(90deg,transparent,${zoneColor}44,transparent)`}}/>

      {/* Messages */}
      <div ref={listRef} style={{flex:1,overflowY:'auto',padding:'14px 14px 8px',
        display:'flex',flexDirection:'column',gap:6,scrollbarWidth:'none'}}>
        {messages.map((msg,i)=>{
          const prev=messages[i-1];
          const showName=!msg.mine&&(!prev||prev.from!==msg.from||prev.type==='system');
          return <Bubble2 key={msg.id} msg={msg} showName={showName} isLast={i===messages.length-1}/>;
        })}
        {isTyping && <TypingDots name={typingName}/>}
      </div>

      {/* Composer */}
      <div style={{padding:'10px 12px 16px',borderTop:'1px solid var(--d2c-border)',
        background:'rgba(10,10,18,0.95)',flexShrink:0}}>
        <div style={{display:'flex',gap:8,alignItems:'flex-end',
          background:'var(--d2c-surface-2)',borderRadius:'var(--d2c-r-lg)',
          border:'1px solid var(--d2c-border)',padding:'8px 8px 8px 14px'}}>
          <button style={{background:'none',border:'none',color:'var(--d2c-text-3)',
            fontSize:18,cursor:'pointer',padding:4,flexShrink:0,fontFamily:'inherit'}}>📎</button>
          <textarea value={input}
            onChange={e=>{setInput(e.target.value);e.target.style.height='auto';e.target.style.height=Math.min(e.target.scrollHeight,100)+'px';}}
            onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send();}}}
            placeholder="type a message…" rows={1}
            style={{flex:1,background:'none',border:'none',resize:'none',
              color:'var(--d2c-text)',fontSize:14,fontFamily:"'DM Sans',sans-serif",
              outline:'none',maxHeight:100,lineHeight:1.5,scrollbarWidth:'none'}}/>
          <button onClick={send}
            style={{width:38,height:38,borderRadius:'50%',flexShrink:0,
              background:input.trim()?'linear-gradient(135deg,var(--d2c-violet),var(--d2c-pink))':'var(--d2c-surface-3)',
              border:'none',color:input.trim()?'#fff':'var(--d2c-text-3)',fontSize:16,
              cursor:input.trim()?'pointer':'default',transition:'all 0.2s',
              display:'flex',alignItems:'center',justifyContent:'center',
              boxShadow:input.trim()?'0 0 16px var(--d2c-violet-glow)':'none',
              fontFamily:'inherit'}}>
            ➤
          </button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ChatScreen2 });
