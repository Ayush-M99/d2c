// d2c — Rich City Map Renderer v3
// Isometric-style buildings, named districts, detailed infrastructure

function drawCityMap(ctx, W, H, offset, scale, layers) {
  ctx.clearRect(0, 0, W, H);
  ctx.save();
  ctx.translate(offset.x, offset.y);
  ctx.scale(scale, scale);

  // ── Sky / Background ──
  const bgGrad = ctx.createLinearGradient(0, 0, 0, H);
  bgGrad.addColorStop(0, '#080814');
  bgGrad.addColorStop(1, '#0A0A18');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  // ── Water ──
  // River flowing through right side
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(W*0.72, 0);
  ctx.bezierCurveTo(W*0.68, H*0.15, W*0.74, H*0.35, W*0.70, H*0.50);
  ctx.bezierCurveTo(W*0.66, H*0.65, W*0.72, H*0.80, W*0.68, H);
  ctx.lineTo(W*0.80, H);
  ctx.bezierCurveTo(W*0.84, H*0.80, W*0.78, H*0.65, W*0.82, H*0.50);
  ctx.bezierCurveTo(W*0.86, H*0.35, W*0.80, H*0.15, W*0.84, 0);
  ctx.closePath();
  const waterGrad = ctx.createLinearGradient(0, 0, 0, H);
  waterGrad.addColorStop(0, '#061428');
  waterGrad.addColorStop(0.5, '#081830');
  waterGrad.addColorStop(1, '#061225');
  ctx.fillStyle = waterGrad;
  ctx.fill();
  // Water shimmer lines
  ctx.strokeStyle = 'rgba(76,201,240,0.06)';
  ctx.lineWidth = 1;
  for (let i = 0; i < 8; i++) {
    ctx.beginPath();
    const ox = (i - 4) * 3;
    ctx.moveTo(W*0.73+ox, H*i*0.12);
    ctx.bezierCurveTo(W*0.70+ox, H*i*0.12+H*0.06, W*0.75+ox, H*i*0.12+H*0.09, W*0.72+ox, H*i*0.12+H*0.12);
    ctx.stroke();
  }
  ctx.restore();

  // Lake bottom-left
  ctx.save();
  const lakeGrad = ctx.createRadialGradient(W*0.10, H*0.82, 0, W*0.10, H*0.82, W*0.12);
  lakeGrad.addColorStop(0, '#0A1A30');
  lakeGrad.addColorStop(1, '#081428');
  ctx.fillStyle = lakeGrad;
  ctx.beginPath();
  ctx.ellipse(W*0.10, H*0.82, W*0.11, H*0.08, -0.2, 0, Math.PI*2);
  ctx.fill();
  ctx.strokeStyle = 'rgba(76,201,240,0.08)';
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.restore();

  // ── District Zones (colored areas) ──
  const districts = [
    { name:'Arts Hub', cx:0.18, cy:0.22, rx:0.14, ry:0.13, color:'#8B5CF6', id:'culture' },
    { name:'Tech Hub', cx:0.52, cy:0.14, rx:0.13, ry:0.10, color:'#4CC9F0', id:'transit' },
    { name:'Gourmet Quarter', cx:0.32, cy:0.50, rx:0.15, ry:0.12, color:'#FF6B35', id:'food' },
    { name:'Nightlife Strip', cx:0.55, cy:0.65, rx:0.12, ry:0.10, color:'#FF3CAC', id:'nightlife' },
    { name:'Riverside Park', cx:0.62, cy:0.42, rx:0.08, ry:0.14, color:'#06D6A0', id:'outdoors' },
    { name:'Cubbon Green', cx:0.14, cy:0.68, rx:0.10, ry:0.09, color:'#06D6A0', id:'outdoors' },
  ];

  districts.forEach(d => {
    if (!layers[d.id]) return;
    // Zone fill
    const zGrad = ctx.createRadialGradient(d.cx*W, d.cy*H, 0, d.cx*W, d.cy*H, Math.max(d.rx*W, d.ry*H)*1.1);
    zGrad.addColorStop(0, d.color + '22');
    zGrad.addColorStop(0.7, d.color + '0C');
    zGrad.addColorStop(1, d.color + '00');
    ctx.fillStyle = zGrad;
    ctx.beginPath();
    ctx.ellipse(d.cx*W, d.cy*H, d.rx*W, d.ry*H, 0, 0, Math.PI*2);
    ctx.fill();
    // Zone border
    ctx.strokeStyle = d.color + '40';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([5, 4]);
    ctx.beginPath();
    ctx.ellipse(d.cx*W, d.cy*H, d.rx*W, d.ry*H, 0, 0, Math.PI*2);
    ctx.stroke();
    ctx.setLineDash([]);
  });

  // ── Road Network ──
  function drawRoad(x1, y1, x2, y2, width, color) {
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(x1*W, y1*H);
    ctx.lineTo(x2*W, y2*H);
    ctx.stroke();
  }
  function drawCurvedRoad(pts, width, color) {
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(pts[0][0]*W, pts[0][1]*H);
    for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0]*W, pts[i][1]*H);
    ctx.stroke();
  }

  // Major arteries
  const majorColor = 'rgba(50,50,95,0.9)';
  const minorColor = 'rgba(30,30,65,0.7)';
  const laneColor = 'rgba(70,70,120,0.12)';

  // Horizontal majors
  [[0,0.18,1,0.18],[0,0.38,0.68,0.38],[0,0.58,0.68,0.58],[0,0.78,0.68,0.78],
   [0.82,0.30,1,0.30],[0.82,0.55,1,0.55],[0.82,0.75,1,0.75]].forEach(r => {
    drawRoad(r[0],r[1],r[2],r[3], 6, majorColor);
    // Center dashes
    ctx.strokeStyle = laneColor;
    ctx.lineWidth = 0.5;
    ctx.setLineDash([4, 6]);
    ctx.beginPath(); ctx.moveTo(r[0]*W,r[1]*H); ctx.lineTo(r[2]*W,r[3]*H); ctx.stroke();
    ctx.setLineDash([]);
  });

  // Vertical majors
  [[0.18,0,0.18,1],[0.38,0,0.38,1],[0.55,0,0.55,0.90],[0.88,0,0.88,1]].forEach(r => {
    drawRoad(r[0],r[1],r[2],r[3], 6, majorColor);
  });

  // Minor roads - horizontal
  [[0,0.08,0.68,0.08],[0,0.28,0.68,0.28],[0,0.48,0.68,0.48],[0,0.68,0.68,0.68],
   [0,0.88,0.68,0.88],[0.82,0.15,1,0.15],[0.82,0.42,1,0.42],[0.82,0.65,1,0.65],[0.82,0.88,1,0.88]].forEach(r => {
    drawRoad(r[0],r[1],r[2],r[3], 2.5, minorColor);
  });

  // Minor roads - vertical
  [[0.08,0,0.08,1],[0.28,0,0.28,1],[0.48,0,0.48,0.90],[0.62,0,0.62,0.35],
   [0.62,0.55,0.62,1],[0.95,0,0.95,1]].forEach(r => {
    drawRoad(r[0],r[1],r[2],r[3], 2.5, minorColor);
  });

  // Diagonal boulevard
  drawCurvedRoad([[0.02,0.02],[0.15,0.12],[0.30,0.30],[0.38,0.38]], 5, majorColor);
  // Another diagonal
  drawCurvedRoad([[0.55,0.58],[0.48,0.68],[0.42,0.78],[0.38,0.90]], 3, minorColor);

  // ── Buildings (isometric-ish 3D blocks) ──
  function drawBuilding(bx, by, bw, bh, floors, color, roofColor) {
    const depth = floors * 2.5;
    const x = bx * W, y = by * H, w = bw * W, h = bh * H;

    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    ctx.fillRect(x + 3, y + 3, w, h);

    // Right face (depth)
    ctx.fillStyle = color + 'AA';
    ctx.beginPath();
    ctx.moveTo(x + w, y);
    ctx.lineTo(x + w + depth*0.5, y - depth*0.3);
    ctx.lineTo(x + w + depth*0.5, y + h - depth*0.3);
    ctx.lineTo(x + w, y + h);
    ctx.closePath();
    ctx.fill();

    // Top face (depth)
    ctx.fillStyle = color + 'CC';
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + depth*0.5, y - depth*0.3);
    ctx.lineTo(x + w + depth*0.5, y - depth*0.3);
    ctx.lineTo(x + w, y);
    ctx.closePath();
    ctx.fill();

    // Front face
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w, h);

    // Windows
    const winW = w * 0.15, winH = h * 0.12;
    const cols = Math.max(1, Math.floor(w / (winW + 2)));
    const rows = Math.max(1, Math.floor(h / (winH + 3)));
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const wx = x + 2 + c * (w / cols);
        const wy = y + 2 + r * (h / rows);
        const lit = Math.random() > 0.4;
        ctx.fillStyle = lit ? 'rgba(255,220,120,0.25)' : 'rgba(0,0,0,0.2)';
        ctx.fillRect(wx + 1, wy + 1, winW - 1, winH - 1);
      }
    }

    // Roof accent
    if (roofColor) {
      ctx.fillStyle = roofColor + '44';
      ctx.fillRect(x, y, w, 1.5);
    }

    // Outline
    ctx.strokeStyle = 'rgba(80,80,140,0.15)';
    ctx.lineWidth = 0.5;
    ctx.strokeRect(x, y, w, h);
  }

  // Seed random for consistent buildings
  let _seed = 42;
  function sRand() { _seed = (_seed * 16807 + 0) % 2147483647; return (_seed & 0x7fffffff) / 0x7fffffff; }

  // Building clusters per district
  const buildingDefs = [
    // Arts Hub area
    {x:0.04,y:0.10,w:0.03,h:0.04,f:4,c:'#1E1840',r:'#8B5CF6'},
    {x:0.09,y:0.11,w:0.04,h:0.03,f:3,c:'#1A1538',r:'#8B5CF6'},
    {x:0.14,y:0.09,w:0.02,h:0.05,f:6,c:'#201845',r:'#8B5CF6'},
    {x:0.20,y:0.12,w:0.03,h:0.03,f:2,c:'#1C1640',r:null},
    {x:0.06,y:0.20,w:0.04,h:0.04,f:5,c:'#1E1842',r:'#8B5CF6'},
    {x:0.12,y:0.22,w:0.03,h:0.03,f:3,c:'#1A1538',r:null},
    {x:0.22,y:0.20,w:0.05,h:0.03,f:2,c:'#181435',r:null},
    {x:0.10,y:0.30,w:0.03,h:0.04,f:4,c:'#1C1640',r:null},
    // Tech Hub area
    {x:0.40,y:0.05,w:0.05,h:0.04,f:8,c:'#142030',r:'#4CC9F0'},
    {x:0.47,y:0.06,w:0.03,h:0.05,f:10,c:'#162535',r:'#4CC9F0'},
    {x:0.52,y:0.04,w:0.04,h:0.03,f:7,c:'#142030',r:'#4CC9F0'},
    {x:0.42,y:0.11,w:0.03,h:0.03,f:5,c:'#162232',r:null},
    {x:0.50,y:0.10,w:0.04,h:0.04,f:9,c:'#142030',r:'#4CC9F0'},
    {x:0.56,y:0.08,w:0.03,h:0.06,f:12,c:'#182838',r:'#4CC9F0'},
    {x:0.44,y:0.16,w:0.02,h:0.03,f:4,c:'#142030',r:null},
    // Gourmet Quarter
    {x:0.20,y:0.40,w:0.04,h:0.03,f:3,c:'#201510',r:'#FF6B35'},
    {x:0.26,y:0.42,w:0.03,h:0.04,f:2,c:'#1E1410',r:'#FF6B35'},
    {x:0.32,y:0.40,w:0.05,h:0.03,f:4,c:'#201510',r:'#FF6B35'},
    {x:0.22,y:0.50,w:0.03,h:0.03,f:2,c:'#1E1410',r:null},
    {x:0.30,y:0.52,w:0.04,h:0.04,f:3,c:'#201510',r:'#FF6B35'},
    {x:0.37,y:0.44,w:0.02,h:0.05,f:5,c:'#221812',r:null},
    {x:0.24,y:0.55,w:0.03,h:0.02,f:2,c:'#1E1410',r:null},
    // Nightlife strip
    {x:0.42,y:0.60,w:0.04,h:0.03,f:3,c:'#201020',r:'#FF3CAC'},
    {x:0.48,y:0.62,w:0.03,h:0.04,f:4,c:'#1E0E1E',r:'#FF3CAC'},
    {x:0.54,y:0.60,w:0.05,h:0.03,f:5,c:'#201020',r:'#FF3CAC'},
    {x:0.44,y:0.68,w:0.03,h:0.03,f:2,c:'#1E0E1E',r:null},
    {x:0.52,y:0.70,w:0.04,h:0.04,f:6,c:'#221225',r:'#FF3CAC'},
    {x:0.60,y:0.62,w:0.02,h:0.05,f:3,c:'#201020',r:null},
    // General fill buildings
    {x:0.04,y:0.42,w:0.03,h:0.03,f:3,c:'#161628',r:null},
    {x:0.10,y:0.44,w:0.04,h:0.02,f:2,c:'#141425',r:null},
    {x:0.04,y:0.52,w:0.02,h:0.04,f:4,c:'#161628',r:null},
    {x:0.30,y:0.22,w:0.03,h:0.03,f:3,c:'#141425',r:null},
    {x:0.34,y:0.10,w:0.04,h:0.04,f:5,c:'#161628',r:null},
    {x:0.40,y:0.22,w:0.03,h:0.02,f:2,c:'#141425',r:null},
    {x:0.04,y:0.82,w:0.03,h:0.03,f:2,c:'#161628',r:null},
    {x:0.20,y:0.82,w:0.04,h:0.03,f:3,c:'#141425',r:null},
    {x:0.30,y:0.80,w:0.03,h:0.04,f:4,c:'#161628',r:null},
    {x:0.42,y:0.82,w:0.05,h:0.03,f:3,c:'#141425',r:null},
    {x:0.52,y:0.80,w:0.03,h:0.04,f:5,c:'#161628',r:null},
    {x:0.60,y:0.82,w:0.02,h:0.03,f:2,c:'#141425',r:null},
    // Across river
    {x:0.84,y:0.08,w:0.04,h:0.04,f:6,c:'#161628',r:null},
    {x:0.90,y:0.10,w:0.03,h:0.03,f:4,c:'#141425',r:null},
    {x:0.85,y:0.20,w:0.05,h:0.03,f:3,c:'#161628',r:null},
    {x:0.84,y:0.35,w:0.03,h:0.04,f:5,c:'#141425',r:null},
    {x:0.90,y:0.38,w:0.04,h:0.03,f:7,c:'#161628',r:'#4CC9F0'},
    {x:0.84,y:0.48,w:0.03,h:0.03,f:3,c:'#141425',r:null},
    {x:0.90,y:0.60,w:0.04,h:0.04,f:4,c:'#161628',r:null},
    {x:0.84,y:0.68,w:0.03,h:0.03,f:2,c:'#141425',r:null},
    {x:0.90,y:0.78,w:0.05,h:0.03,f:3,c:'#161628',r:null},
  ];

  // Sort by y for depth ordering
  buildingDefs.sort((a,b) => a.y - b.y);
  buildingDefs.forEach(b => drawBuilding(b.x, b.y, b.w, b.h, b.f, b.c, b.r));

  // ── Parks ──
  function drawPark(px, py, pw, ph, name) {
    const x=px*W, y=py*H, w=pw*W, h=ph*H;
    // Ground
    const pGrad = ctx.createRadialGradient(x+w/2,y+h/2, 0, x+w/2,y+h/2, Math.max(w,h)/1.8);
    pGrad.addColorStop(0, 'rgba(6,214,160,0.14)');
    pGrad.addColorStop(1, 'rgba(6,214,160,0.03)');
    ctx.fillStyle = pGrad;
    ctx.beginPath(); ctx.roundRect(x,y,w,h, 8); ctx.fill();
    // Border
    ctx.strokeStyle = 'rgba(6,214,160,0.18)';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(x,y,w,h, 8); ctx.stroke();
    // Trees (clusters)
    for (let i = 0; i < 14; i++) {
      const tx = x + 6 + (sRand() * (w-12));
      const ty = y + 6 + (sRand() * (h-12));
      const tr = 2 + sRand() * 3;
      ctx.fillStyle = `rgba(6,214,160,${0.15 + sRand()*0.15})`;
      ctx.beginPath(); ctx.arc(tx, ty, tr, 0, Math.PI*2); ctx.fill();
      // Tree shadow
      ctx.fillStyle = 'rgba(0,0,0,0.15)';
      ctx.beginPath(); ctx.ellipse(tx+1.5, ty+tr*0.8, tr*0.8, tr*0.3, 0, 0, Math.PI*2); ctx.fill();
    }
    // Paths through park
    ctx.strokeStyle = 'rgba(6,214,160,0.08)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(x, y+h*0.5);
    ctx.bezierCurveTo(x+w*0.3, y+h*0.3, x+w*0.7, y+h*0.7, x+w, y+h*0.5);
    ctx.stroke();
    // Label
    ctx.font = "bold 8px 'Space Grotesk', sans-serif";
    ctx.fillStyle = 'rgba(6,214,160,0.40)';
    ctx.textAlign = 'center';
    ctx.fillText(name, x+w/2, y+h+10);
  }

  drawPark(0.56, 0.36, 0.10, 0.14, 'Riverside Park');
  drawPark(0.06, 0.62, 0.14, 0.10, 'Cubbon Green');

  // ── Bridges over river ──
  ctx.strokeStyle = 'rgba(60,60,100,0.8)';
  ctx.lineWidth = 7;
  [[0.68,0.28,0.84,0.28],[0.68,0.52,0.84,0.52],[0.66,0.75,0.84,0.75]].forEach(b => {
    ctx.beginPath(); ctx.moveTo(b[0]*W,b[1]*H); ctx.lineTo(b[2]*W,b[3]*H); ctx.stroke();
    // Bridge rails
    ctx.strokeStyle = 'rgba(80,80,130,0.3)';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(b[0]*W,b[1]*H-3); ctx.lineTo(b[2]*W,b[3]*H-3); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(b[0]*W,b[1]*H+3); ctx.lineTo(b[2]*W,b[3]*H+3); ctx.stroke();
    ctx.strokeStyle = 'rgba(60,60,100,0.8)';
    ctx.lineWidth = 7;
  });

  // ── District Labels ──
  districts.forEach(d => {
    if (!layers[d.id]) return;
    ctx.save();
    ctx.font = "bold 10px 'Space Grotesk', sans-serif";
    ctx.textAlign = 'center';
    ctx.fillStyle = d.color + '88';
    // Text background
    const tw = ctx.measureText(d.name).width + 12;
    ctx.fillStyle = 'rgba(10,10,18,0.75)';
    ctx.beginPath();
    ctx.roundRect(d.cx*W - tw/2, d.cy*H - d.ry*H*0.85 - 8, tw, 18, 4);
    ctx.fill();
    ctx.strokeStyle = d.color + '44';
    ctx.lineWidth = 0.8;
    ctx.beginPath();
    ctx.roundRect(d.cx*W - tw/2, d.cy*H - d.ry*H*0.85 - 8, tw, 18, 4);
    ctx.stroke();
    // Text
    ctx.fillStyle = d.color + 'CC';
    ctx.fillText(d.name, d.cx*W, d.cy*H - d.ry*H*0.85 + 4);
    ctx.restore();
  });

  // ── Street Labels ──
  ctx.font = "500 7px 'JetBrains Mono', monospace";
  ctx.textAlign = 'center';
  const streets = [
    {x:0.28,y:0.17,text:'MG ROAD',r:0},
    {x:0.50,y:0.37,text:'BRIGADE RD',r:0},
    {x:0.38,y:0.08,text:'CHURCH ST',r:-90},
    {x:0.18,y:0.45,text:'COMMERCIAL ST',r:-90},
    {x:0.34,y:0.57,text:'CUNNINGHAM RD',r:0},
    {x:0.55,y:0.45,text:'RESIDENCY RD',r:-90},
    {x:0.50,y:0.77,text:'100 FEET RD',r:0},
    {x:0.88,y:0.25,text:'OUTER RING',r:-90},
  ];
  streets.forEach(s => {
    ctx.save();
    ctx.translate(s.x*W, s.y*H);
    if (s.r) ctx.rotate(s.r * Math.PI/180);
    // Text bg
    const tw = ctx.measureText(s.text).width + 6;
    ctx.fillStyle = 'rgba(10,10,18,0.6)';
    ctx.fillRect(-tw/2, -6, tw, 11);
    ctx.fillStyle = 'rgba(90,90,150,0.50)';
    ctx.fillText(s.text, 0, 2);
    ctx.restore();
  });

  // ── Compass ──
  ctx.save();
  ctx.translate(W - 30, 30);
  ctx.strokeStyle = 'rgba(140,140,200,0.3)';
  ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(0,-10); ctx.lineTo(0,10); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-10,0); ctx.lineTo(10,0); ctx.stroke();
  ctx.fillStyle = 'rgba(140,140,200,0.4)';
  ctx.font = "bold 7px 'Space Grotesk', sans-serif";
  ctx.textAlign = 'center';
  ctx.fillText('N', 0, -13);
  ctx.restore();

  // ── Scale bar ──
  ctx.save();
  ctx.strokeStyle = 'rgba(100,100,160,0.3)';
  ctx.lineWidth = 1.5;
  const sbx = 16, sby = H - 16;
  ctx.beginPath(); ctx.moveTo(sbx, sby); ctx.lineTo(sbx+50, sby); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(sbx, sby-3); ctx.lineTo(sbx, sby+3); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(sbx+50, sby-3); ctx.lineTo(sbx+50, sby+3); ctx.stroke();
  ctx.fillStyle = 'rgba(100,100,160,0.35)';
  ctx.font = "6px 'JetBrains Mono', monospace";
  ctx.textAlign = 'center';
  ctx.fillText('200m', sbx+25, sby-5);
  ctx.restore();

  ctx.restore();
}

window.drawCityMap = drawCityMap;
