// d2c — App Shell v3

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "dark",
  "animatePins": true,
  "vibrancy": "high"
}/*EDITMODE-END*/;

function D2CApp() {
  const [screen, setScreen] = React.useState('map');
  const [selectedThread, setSelectedThread] = React.useState(null);
  const [darkMode, setDarkMode] = React.useState(true);
  const [showTweaks, setShowTweaks] = React.useState(false);

  // Tweaks panel protocol
  React.useEffect(() => {
    const handler = (e) => {
      if (e.data?.type === '__activate_edit_mode') setShowTweaks(true);
      if (e.data?.type === '__deactivate_edit_mode') setShowTweaks(false);
    };
    window.addEventListener('message', handler);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', handler);
  }, []);

  const navigateTo = (s, t) => {
    if (t) setSelectedThread(t);
    setScreen(s);
  };

  return (
    <div style={{width:'100%',height:'100%',position:'relative',
      fontFamily:"'DM Sans',sans-serif",overflow:'hidden',
      background:darkMode?'var(--d2c-bg)':'#F5F5F8',
      color:darkMode?'var(--d2c-text)':'#111'}}>

      <D2CStyles/>

      {screen === 'map' && (
        <MapScreen3
          onThreadSelect={t => navigateTo('chat', t)}
          darkMode={darkMode}
          setDarkMode={setDarkMode}
        />
      )}
      {screen === 'chat' && (
        <ChatScreen2
          thread={selectedThread}
          onBack={() => setScreen('map')}
          darkMode={darkMode}
        />
      )}

      {showTweaks && (
        <TweaksPanel onClose={() => {
          setShowTweaks(false);
          window.parent.postMessage({ type: '__edit_mode_dismissed' }, '*');
        }}>
          <TweakSection title="Navigate">
            <TweakButton label="→ Map Home" onClick={() => setScreen('map')} />
            <TweakButton label="→ Chat View" onClick={() => {
              setSelectedThread(D2C_THREADS[0]);
              setScreen('chat');
            }} />
          </TweakSection>
          <TweakSection title="Theme">
            <TweakToggle label="Dark Mode" value={darkMode}
              onChange={v => setDarkMode(v)} />
          </TweakSection>
        </TweaksPanel>
      )}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<D2CApp />);
